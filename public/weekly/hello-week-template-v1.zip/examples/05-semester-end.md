<!-- opslion:hello-week/v1 -->
# Hello Week丨学期收官（排版示例）
<!-- layout: inset -->

:::banner
:::

:::code-intro semester-end
:::

:::divider
:::

:::callout 关于投稿
欢迎在栏目中分享日常感受、书影音推荐和摄影作品，让灵感与生活在这里相遇。

署名方式由投稿人决定。下图为不可扫码的占位图，请替换为本期的投稿入口。

![投稿二维码占位图](asset:submission-qr)

> 这里填写本期投稿征集说明或入选奖励。
:::

:::divider
:::

:::section 上周回顾
:::

:::category 学术信息
:::

:::news 示例学术报告 1
- 时间：以原文为准的示例时间
- 地点：示例会场
- 报告人：示例研究者
- 主持人：示例主持人
- 内容：这是一段用于检验自动增高的摘要。生成文案时请替换为来源支持的具体内容，保留重点、限制条件与报名截止信息。
- 详情请见：[示例学术报告原文](https://example.com/articles/1)
:::

:::category 活动信息
:::

:::news 示例交流活动 2
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[示例交流活动原文](https://example.com/articles/2)
:::

:::news 示例校园活动 3
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[示例校园活动原文](https://example.com/articles/3)
:::

:::news 示例校园活动 4
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[示例校园活动原文](https://example.com/articles/4)
:::

:::news 示例校园活动 5
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[示例校园活动原文](https://example.com/articles/5)
:::

:::divider
:::

:::section 下周及后续
:::

:::category 活动信息
:::

:::news 示例多场次活动
- 毕业合影：
  时间：场次一的示例时间
  地点：场次一的示例地点
- 毕业典礼：
  时间：场次二的示例时间
  地点：场次二的示例地点
- 互动展示：
  时间：场次三的示例时间
  地点：场次三的示例地点
- 详情请见：[示例多场次活动原文](https://example.com/graduation)
:::

:::divider
:::

:::transition
记得查收重要提示哦
:::

:::notice 期末提醒
- 这里填写复习、作息或其他本期提醒。
:::

:::divider
:::

:::code-outro
:::

:::image
![学期收尾装饰](asset:heart)
:::

:::closing
这里填写学期收尾的第一段寄语。
【Hello Week】与大家一起走过一个学期。

```cpp
void EndOfSpringSemester()
{
  puts("Hello weeks...");
  puts("Goodbye weeks...");
```

这里填写本学期的回顾与祝福。
换行会按原文保留，段落可自然增高。

```cpp
  puts("Heart for YOU");
```

这里填写对假期的期待。

```cpp
  grades++;
  vacation_countdown--;
```

【Hello Week】，与你不见不散。

```cpp
  puts("Hello Summer!");
}
```
:::

:::spacer 28
:::

:::footer
:::