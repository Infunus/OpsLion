<!-- opslion:hello-week/v1 -->
# Hello Week丨信息汇总（排版示例）
<!-- layout: classic -->

:::banner
:::

:::code-intro
:::

:::divider
:::

:::callout 关于投稿
欢迎在栏目中分享日常感受、书影音推荐和摄影作品，让灵感与生活在这里相遇。

署名方式由投稿人决定。下图为不可扫码的占位图，请替换为本期的投稿入口。

![投稿二维码占位图](asset:submission-qr)

> 这里填写本期投稿征集说明或入选奖励。
:::

:::divider
:::

:::section 上周回顾
:::

:::category 学术信息
:::

:::news 示例学术报告 1
- 时间：以原文为准的示例时间
- 地点：示例会场
- 报告人：示例研究者
- 主持人：示例主持人
- 内容：这是一段用于检验自动增高的摘要。生成文案时请替换为来源支持的具体内容，保留重点、限制条件与报名截止信息。
- 详情请见：[示例学术报告原文](https://example.com/articles/1)
:::

:::category 活动信息
:::

:::news 示例交流活动 2
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[示例交流活动原文](https://example.com/articles/2)
:::

:::news 示例校园活动 3
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[示例校园活动原文](https://example.com/articles/3)
:::

:::news 示例校园活动 4
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[示例校园活动原文](https://example.com/articles/4)
:::

:::news 示例校园活动 5
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[示例校园活动原文](https://example.com/articles/5)
:::

:::news 示例校园活动 6
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[示例校园活动原文](https://example.com/articles/6)
:::

:::news 示例校园活动 7
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[示例校园活动原文](https://example.com/articles/7)
:::

:::divider
:::

:::transition
看完了上周信息
再来看看下周及后续的重要信息吧
:::

:::section 下周及后续
:::

:::category 学术信息
:::

:::news 示例讲座 21
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[示例讲座原文](https://example.com/articles/21)
:::

:::category 活动信息
:::

:::news 示例报名活动 22
- 时间：以原文为准的示例时间
- 地点：示例会场
- 报名截止：以原文为准的示例截止时间
- 面向对象：示例对象
- 注意事项：请保留来源列明的限制条件。
- 详情请见：[示例报名活动原文](https://example.com/articles/22)
:::

:::news 示例讲座 23
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[示例讲座原文](https://example.com/articles/23)
:::

:::news 示例讲座 24
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[示例讲座原文](https://example.com/articles/24)
:::

:::news 示例讲座 25
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[示例讲座原文](https://example.com/articles/25)
:::

:::divider
:::

:::transition
看完了后续信息
记得查收重要提示哦
:::

:::section 重要提示
:::

:::notice 本期提醒
- 本段仅为排版样例，请填写本期需要提醒的事项。
- 信息没有可靠依据时，请在外部生成阶段补充依据。
:::

:::divider
:::

:::code-outro
:::

:::spacer 24
:::

:::footer
:::