<!-- opslion:hello-week/v1 -->
# Hello Week丨全部模块示例
<!-- layout: inset -->

:::welcome 欢迎语标题
欢迎语可以分段。

![开学插画](asset:welcome)
:::

:::banner
:::

:::code-intro semester-end
:::

:::divider
:::

:::callout 关于投稿
欢迎在栏目中分享日常感受、书影音推荐和摄影作品，让灵感与生活在这里相遇。

署名方式由投稿人决定。下图为不可扫码的占位图，请替换为本期的投稿入口。

![投稿二维码占位图](asset:submission-qr)

> 这里填写本期投稿征集说明或入选奖励。
:::

:::divider
:::

:::section 上周回顾
:::

:::category 学术信息
:::

:::news 示例学术报告 1
- 时间：以原文为准的示例时间
- 地点：示例会场
- 报告人：示例研究者
- 主持人：示例主持人
- 内容：这是一段用于检验自动增高的摘要。生成文案时请替换为来源支持的具体内容，保留重点、限制条件与报名截止信息。
- 详情请见：[示例学术报告原文](https://example.com/articles/1)
:::

:::divider
:::

:::transition
看完了上周信息
再来看看下周及后续的重要信息吧
:::

:::section 下周及后续
:::

:::category 学术信息
:::

:::news 示例讲座 21
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[示例讲座原文](https://example.com/articles/21)
:::

:::divider
:::

:::transition
看完了后续信息
记得查收重要提示哦
:::

:::section 重要提示
:::

:::notice 提醒标题
- 本段仅为排版样例，请填写本期需要提醒的事项。
- 信息没有可靠依据时，请在外部生成阶段补充依据。
:::

:::image
![装饰图](asset:heart)
:::

:::code
const weekly = "自定义代码段";
:::

:::divider
:::

:::contact 联系我们
如有建议或需要协助，请通过公开联系渠道联系栏目团队。

公共邮箱：weekly@example.com

联系人：示例联系人（请由生成文案的 skill 填写当期信息）
:::

:::code-outro
:::

:::closing
这里填写学期收尾的第一段寄语。
【Hello Week】与大家一起走过一个学期。

```cpp
void EndOfSpringSemester()
{
  puts("Hello weeks...");
  puts("Goodbye weeks...");
```

这里填写本学期的回顾与祝福。
换行会按原文保留，段落可自然增高。

```cpp
  puts("Heart for YOU");
```

这里填写对假期的期待。

```cpp
  grades++;
  vacation_countdown--;
```

【Hello Week】，与你不见不散。

```cpp
  puts("Hello Summer!");
}
```
:::

:::spacer 24
:::

:::credits 示例编辑团队
文案丨示例作者
排版丨示例排版人员
校对丨示例署名
:::

:::footer
:::