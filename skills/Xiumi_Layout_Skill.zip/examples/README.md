# 可重复运行的合成示例

全部内容为本 skill 制作的测试数据，不是用户真实稿件。灰蓝色矩形是确定性生成的测试图片，不是漏图。模板也为合成母版，采用插件 v2 原始导出结构；原插件 capturePage 实际抓取结果的兼容性另由 browser_contract 测试覆盖。

- `raw.opslion-template.json`：未做语义预处理的原始模板，有旧标题、旧日期、旧链接、旧图和固定栏目。
- `source.docx`：有效 Word 文档，包含本期标题、加粗日期、新链接、内嵌图片。
- `layout.plan.json`：对应这两个输入的已完成计划；它是示例答案，实际稿件必须由模型自行分析生成。
- `article.xiumi.json`：对应的 Bridge v3 交付结果，含 4 个独立模块、1 张内嵌图片。
- `preview.html`、`review.html`、`validation.json`：实际产物，不是效果示意。

在本 skill 目录运行：

```bash
python examples/reproduce.py --out demo
python scripts/xiumi_skill.py validate demo/delivery/article.xiumi.json
```

使用新的空目录，以免覆盖上一轮工作。generatedAt 随运行改变，其他语义、模板和模块映射应一致。DOCX 已通过独立渲染检查；交付 HTML 已检查 375px 和 430px 预览。

reproduce.py 只对这两个附带的合成输入重放示例映射，并将哈希绑定到本次真实提取结果；这样没有 Pillow 的纯标准库环境也能重复运行。真实稿件必须重新制定计划，不能重用示例映射。
