#!/usr/bin/env python3
"""Rebuild the bundled synthetic example. No model API, no OpsLion service.
The sample mapping is fixed; hashes are bound to THIS run's parsed sample metadata.
"""
import argparse,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'scripts'))
from xiumi_skill import prepare,read_json,write_json,compile_workspace

def main():
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--out',required=True);args=a.parse_args();out=Path(args.out)
    prepare(HERE/'raw.opslion-template.json',[HERE/'source.docx'],out/'workspace')
    plan=read_json(HERE/'layout.plan.json')
    plan['materialsHash']=read_json(out/'workspace/materials.json')['hash']
    plan['templateHash']=read_json(out/'workspace/template.analysis.json')['templateHash']
    write_json(out/'layout.plan.json',plan)
    print(json.dumps(compile_workspace(out/'workspace',out/'layout.plan.json',out/'delivery'),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
