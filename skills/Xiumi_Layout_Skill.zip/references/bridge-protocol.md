# 协议：必须与用户现有插件对接

## 证据与适配范围

适配依据是用户上传的 `OpsLion(2).zip`，扩展 manifest 版本 **0.4.0**。使用了以下实际代码，而非自行发明导入 JSON：

- `integrations/xiumi-bridge/capture-page.js`、`popup.js`：导出模板。
- `integrations/xiumi-bridge/payload.js`：识别导入文件。
- `integrations/xiumi-bridge/page-runtime.js`：素材上传、原生模块创建、事务回滚、保存重开核验。
- `app/studio/bridge-contract.ts`、`bridge-package.ts`、`page-format.ts`：完整原生模块和全文格式契约。

文件哈希与来源路径见 `SOURCE_MANIFEST.json`。后续修正说明没有附新版源码；本包不声称与尚未检查的新协议自动兼容。插件版本 0.4.0、模板协议 v2、交付协议 v3 是三种不同版本号。

## 1. 输入：原始模板包

典型名称：`母版.opslion-template.json`。

```json
{
  "schema": "opslion-template/v2",
  "title": "往期文章标题",
  "sourceType": "xiumi",
  "renderedPreview": false,
  "html": "<section style=\"...\">未经语义拆解的实际正文 DOM</section>",
  "source": {
    "url": "https://xiumi.us/studio/v5#/paper/for/123/cube/0",
    "paperId": "123",
    "capturedAt": "2026-09-11T00:00:00Z",
    "pageFormat": {
      "styles": {"font-size":"14px","line-height":"28px"},
      "source": {"selector":".tn-page-inst > .tn-comp-style-pin"}
    },
    "modules": [{"index":0,"cells":["原文字"]}],
    "nativeModuleHashes": ["来源组件哈希，可能没有"]
  }
}
```

示例仅说明结构，不能复制其中的假哈希进入产物。以实际模板现有字段为准。`html` 没有语义标签、没有槽位库是正常输入；解析是 skill 的任务。捕获器可能保留 `.tn-comp-top-level` 和 `data-layout-origin` 线索，但不等于组件已经模块化。

旧 `opslion-template/v1` 可走基础 HTML 槽位路线。缺失计算后的全文格式时仅使用原 HTML 已有值并记录限制。纯 HTML 只作为显式回退，不能保证包含插件抓取时的全部环境样式。整页网页源码、截图及 `xiumi-bridge/v3` 成稿不能冒充原始模板。

## 2. 输出：Bridge v3 交付文件

真正由用户在扩展里选择的文件是 `article.xiumi.json`，不是 skill ZIP、模板包、计划或工作 ZIP。

```json
{
  "schema":"xiumi-bridge/v3",
  "title":"本期文章标题",
  "html":"<section style=\"font-size:14px\">与 native.modules 相同的正文</section>",
  "plainText":"正文纯文字",
  "generatedAt":"2026-09-11T00:00:00Z",
  "native":{
    "modules":[
      {"id":"module-1","html":"<section>标题与完整装饰壳</section>"},
      {"id":"module-2","html":"<section><img src=\"opslion-asset://asset-1\"></section>"}
    ],
    "pageFormat":{"styles":{"font-size":"14px"}}
  },
  "assets":[
    {"id":"asset-1","src":"data:image/png;base64,真实完整数据",
     "kind":"image","occurrences":1,"status":"embedded","bytes":1234}
  ],
  "assetSummary":{"embedded":1,"embeddedBytes":1234,"local":0},
  "patch":{"available":false,"operations":[],"reasons":["用于空白图文分模块导入"]}
}
```

程序负责生成所有大小、摘要、完整 base64、时间和 ID；模型不手写猜测这些数值。相同内嵌图片在 assets 中保存一次；模块和页面背景引用 `opslion-asset://asset-N`。远程图片保留实际 HTTP(S) 地址并登记素材清单；不使用临时本地路径、ChatGPT 下载 URL 或假秀米图床地址。

`native.modules` 是实际被导入的内容，`html` 必须从同一份模块和全文样式组合，不能有两个各自生成的版本。模块含完整包装；页级 padding、字号等只施加一次。

全文样式允许：`font-family`、`font-size`、`line-height`、`letter-spacing`、`color`、`text-align`、`text-indent`、四个 padding 长属性、`background-color`、`background-image`、`background-size`、`background-position`、`background-repeat`。没有“随便加入一个 CSS 字段”的扩展方式。

## 3. 原样不是忽略插件限制

原模板允许的 SVG 可保留，包括 foreignObject、渐变、本地 defs 引用；克隆时所有 ID 和引用要同步重映射。当前导入器对 SMIL 的 `attributeName` 只接受 `viewBox/height/width/x/y/opacity/transform/visibility`。不得因为上游 HTML 能显示其他动画，就宣称这个导入器支持。

插件拒绝脚本、事件属性、iframe、表单等活动内容及部分 CSS 动态表达式。SKILL 的编译器会显式失败，不偷偷删除原模板的关键动画/样式后说“完全保真”。PNG/JPEG/GIF/WebP/AVIF 为内嵌图片路线；EMF/WMF/SVG 文件等需明确转换策略，不能只改扩展名。

扩展写入前限制：模块 1–5000；上传后的原生 JSON 不超过约 1,500,000 字符。本脚本对模块 HTML 采用 1,350,000 字符保守门槛，不能保证绕过上传后更大的实际 JSON。单张图片 12 MiB、单文件 64 MiB、原材料累计 256 MiB、嵌套 ZIP 四层是本 skill 的资源安全上限，不是秀米官方配额。

## 4. 导入操作与验证等级

默认在**新建空白图文**选择文件、分模块导入；已有母版保持不动。每个导出模块由扩展创建一个原生文字组件，模块内部保留 HTML/SVG。这里不承诺把原模板每一个装饰元素重新创建成相同类型的原生专用组件。

嵌入图由扩展调用秀米当前页面的上传服务，远程图按其导入流程搬运。先上传并核对结果，再事务写入；失败时不留下半篇文章。本 skill 不获取用户账号，不替用户执行保存，不编造上传结果。

`patch.available=false` 是有意的安全默认值；从原模板取得的组件 hash 不足以让任意新稿安全原位覆盖。没有逐项对应和用户授权，不生成 in-place patch。

验证分层：脚本结构校验 → 可选浏览器渲染 → 扩展成功写入 → 用户保存并重新打开后核验。只有前一层成功不能证明后一层成功。首次/每次真实交付都按扩展提示完成最后核验。
