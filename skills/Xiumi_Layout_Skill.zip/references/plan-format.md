# 可执行排版计划 v1

计划由执行 skill 的模型基于实际材料编写；用户不需要填写。使用脚本产生的 starter、节点 ID、来源 ID 和 hash。完整例子见 `examples/layout.plan.json`，与同目录模板/材料配套；不能套用示例 ID 到别的模板。

## 1. 总体结构

```json
{
  "schema":"opslion-web-layout-plan/v1",
  "templateHash":"从 template.analysis.json 复制",
  "materialsHash":"从 materials.json 复制",
  "title":"来自本期主稿的标题",
  "mode":"new-article",
  "operations":[],
  "moduleBoundaries":["真实的完整元素 ID"],
  "templateRetain":{},
  "imageRetain":{},
  "sourceDispositions":{},
  "assetDispositions":{},
  "issueResolutions":{},
  "unresolved":[]
}
```

`templateHash` 对原始 html 哈希；`materialsHash` 对规范化来源数据哈希。不是模型信心分。来源 JSON 不允许为了修改内容直接编辑；人工修订见第 7 节。源文本使用 B00001 等 ID；图片素材 A0001 等；节点是 e/t 前缀；U 前缀为本次用户授权补充。

## 2. 文字 text

```json
{"op":"text","target":"t00012","expected":"旧日期","parts":[{"source":"B00002","start":4,"end":9}]}
```

`target` 必须是目录中实际文字叶节点。`expected` 完全等于该节点旧文，不能随便填。引用范围 `[start,end)` 按 **Python Unicode code point**，不是 UTF-16、字节或按显示宽度计数。省略 start/end 表示整个来源块。

实际计算范围而非心算：

```python
text = block['text']
start = text.index('10月1日')
end = start + len('10月1日')
assert text[start:end] == '10月1日'
```

一个 text 可引用多个 source 范围，但脚本不会自行在范围之间插入空格或段落。需要不同段落时重复已有 p/模块；不要把两段直接拼到一个 text 里。需要清空旧槽时 `parts:[]` 并填写 `reason`。

所有源非空白字符必须有去向；同一块全部被使用或全部明确处置。某块同时含编辑说明和正文时，不要掩盖剩余字符：先对实际原文建立可复核分段，或使用支持该细粒度的解析补充，保留父来源和字符范围，再重建 hash/计划。不得通过 sourceDispositions 一边用一边排除。

## 3. 链接 link

```json
{"op":"link","target":"e00024","expectedHref":"https://example.com/old","href":"https://example.com/new","source":"B00002"}
```

目标必须是实际 anchor，source 的 runs 中要有新 href；用户直接改地址则使用 `userEvidence` 记录本轮要求。去掉链接需要空 href + reason。整段文字恰是完整 anchor 时 text 会按源链接更新；多叶节点 anchor 用 link 先统一更新，然后 text 分段。

来源只有一部分是链接时，不能把无链接前缀也塞进固定 anchor。允许的目标是合法 HTTP(S) 地址；邮件协议、内部书签等不在当前插件交付路线，需明确处理，不能悄悄变成假 URL。

## 4. 图片 image

```json
{"op":"image","target":"e00035","asset":"A0001","source":"B00003","alt":"活动合影"}
```

针对 img 或 SVG image。DOCX 内图片用 source 定位实际出现位置，asset 必须对应其来源。外置照片没有 B 图片块时：

```json
{"op":"image","target":"e00035","asset":"A0004","evidence":"主稿“图2：现场合影”与压缩包 图2-合影.jpg 对应"}
```

图片定位标记自身作为 `image-anchor` 分类。alt 可由实际内容或用户提供，不编造场景。宽高和 CSS 不改，srcset 旧资源移除以免新 src 被旧图覆盖。每个重复实例独立处理图片，不能因为同 ID 的另一个实例换了就认为全部换过。

## 5. 重复与删除完整原模块

```json
{
  "op":"repeat","target":"e00008","reason":"本期有两个同级章节，沿用原章节壳",
  "instances":[
    {"operations":[{"op":"text","target":"t00012","expected":"示例正文","parts":[{"source":"B00004"}]}]},
    {"operations":[{"op":"text","target":"t00012","expected":"示例正文","parts":[{"source":"B00005"}]}]}
  ]
}
```

target 为完整子元素，不是当前 scope 根；每个实例内部使用原子树的 ID。脚本克隆、局部更新、重映射 SVG/DOM ID 与引用。可嵌套 repeat，但必须选择完整下一级区域，不遗漏同一图组内部的其他槽。1–500 实例的限制防止意外爆炸。

```json
{"op":"remove","target":"e00070","expectedHash":"目录节点的真实 hash","reason":"本期不使用这组示例图文，源文没有因此被删除"}
```

删除的必须是完整原区域，hash 需要与操作发生前一致。无需的模板样例可以删除；真实材料内容不能跟着无依据删除。删除唯一根区域不允许；调整整个单根不可重复模板时，选择其内部可独立壳或降级告知。

## 6. 旧内容、未使用内容与问题

```json
{
 "templateRetain":{
   "t00055":{"role":"permanent-brand","reason":"此处是固定栏目名，而不是旧活动标题"}
 },
 "imageRetain":{
   "e00002":{"role":"decoration","reason":"母版的装饰底纹，不是本期活动照片"}
 },
 "sourceDispositions":{
   "B00008":{"action":"image-anchor","reason":"照片位置说明，不是正文","evidence":"原稿“此处放图2”对应 A0002"},
   "B00009":{"action":"user-excluded","reason":"用户删除本段","evidence":"本轮明确要求删除第3段"}
 },
 "assetDispositions":{
   "A0003":{"reason":"用户注明备用图，本期未使用"}
 },
 "issueResolutions":{
   "Q0001":{"action":"confirmed-visible-version","evidence":"用户明确要求采用原稿当前显示的修订版本"}
 }
}
```

templateRetain role 只允许 decoration / permanent-brand / user-authorized-reuse；imageRetain 只允许 decoration / user-authorized-reuse。CSS url 背景同样需要确认。

sourceDispositions action 只允许 instruction / image-anchor / superseded / user-excluded。每个条目必须 reason + evidence；模板作者的样例文案不是本文事实依据。编译器验证条目存在和覆盖，无法独立证明授权是否真实；模型与人工须审阅证据。

原文重复展示时使用 `duplicateSources:{"B00002":{"reason":"用户明确要求正文与结尾各显示一次同一报名信息"}}`；不得把它当作通用允许重复开关。

`unresolved` 非空会拦截正式成稿。无法处理 Q 不能删除原 Q；先处理源内容并留下决策。表格转文字需要用户同意或已有明确任务说明，并保留行列含义；不能只有“已处理”三个字。

## 7. 用户改字/加字/删字，来源不变

```json
{
 "userAdditions":[{"id":"U1","text":"用户指定的新标题","evidence":"本轮用户明确修改标题"}],
 "sourceDispositions":{
   "B00001":{"action":"superseded","reason":"标题人工修订","evidence":"本轮修改要求"}
 }
}
```

对应 text 操作改为引用 U1。U 条目可提供与 text 完全一致的 runs 以保留链接/强调。这里只能放真实授权内容，不是允许模型润色的自由 literal。

用户只改一部分时，构造该块的完整新版本 U，保存 before/after 差异；旧 B 保留且标记被取代。不以修改 hash 的方式直接覆盖原文。删除节点以用户要求作为 reason，并登记对应 sourceDisposition，下一次不得自动补回。

## 8. 后补文件保持 ID 稳定

```bash
python S/scripts/xiumi_skill.py extend --workspace W --materials 新二维码.png 补充说明.docx --out W2
```

命令将新材料追加到来源账本，不重新编号旧 B/A/F/Q；相同图片按哈希复用。已有 `layout.plan.json` 会复制并更新 materialsHash；新增内容尚未映射，不能认为自动排好了。认真读取 W2 的新增来源，修改相关操作；旧决定不受影响。之后输出到新的交付目录，不覆盖旧版。

从 work.zip 恢复时，使用其中 workspace 目录；脚本不需要用户重传已提取的旧 Word/图片。补图文件和新版本材料仍需上传。work.zip 中保留的原提取结果不是原始 DOCX/ZIP 二进制档案。
