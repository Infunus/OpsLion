#!/usr/bin/env python3
"""Deterministic half of the Xiumi layout skill. Python 3.10+, standard library.
The assistant supplies an evidence-backed plan; this program never calls a model.
"""
from __future__ import annotations
import argparse, base64, json, re, sys, zipfile, traceback
from collections import Counter
from datetime import datetime, timezone
from html import escape
from pathlib import Path
from urllib.parse import urlparse
from xiumi_dom import (Node,LayoutError,parse_html,content_root,get_node,replace_node,nearest,
 ancestors,top_modules,partition,css_parse,css_string,scope_clone_ids,digest,PAGE_PROPERTIES,URL_RE,BAD_STYLE)
from materials import ingest, image_info, Ingest, MAX_FILE

SCHEMA='opslion-web-layout-plan/v1'
ROOT=Path(__file__).resolve().parent.parent

def read_json(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def write_json(path,obj):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def clean_summary(value):
    if isinstance(value,dict):return {k:clean_summary(v) for k,v in value.items() if k!='src' or not isinstance(v,str) or not v.startswith('data:')}
    if isinstance(value,list):return [clean_summary(v) for v in value]
    if isinstance(value,str):return re.sub(r'data:image/[^,;]+;base64,[a-zA-Z0-9+/=]+','[embedded image]',value)
    return value

def load_template(path):
    raw=Path(path).read_text(encoding='utf-8-sig')
    if Path(path).suffix.lower() in ('.html','.htm'):packet={'schema':'raw-html','title':Path(path).stem,'html':raw}
    else:packet=json.loads(raw)
    if packet.get('schema') not in ('opslion-template/v1','opslion-template/v2','raw-html'):raise LayoutError('输入须为插件直接导出的 opslion-template/v1 或 v2，不是 Bridge 成稿包')
    if not isinstance(packet.get('html'),str) or not packet['html'].strip():raise LayoutError('模板缺少原始 html')
    tree=parse_html(packet['html']);root=content_root(tree)
    if root.tag in ('html','body'):raise LayoutError('请使用插件正文导出包，而不是整页浏览器源码')
    if root.tag=='svg':
        sec=Node('section',uid='svg-wrapper');replace_node(root,[sec]);sec.add(root);root=sec
    pf=packet.get('source',{}).get('pageFormat') or packet.get('pageFormat')
    warnings=[]
    if not pf:
        st=css_parse(root.attrs.get('style',''));styles={k:v for k,v in st.items() if k in PAGE_PROPERTIES}
        if 'padding' in st:
            v=st['padding'].split()
            if 1<=len(v)<=4:
                vals=[v[0]]*4 if len(v)==1 else [v[0],v[1],v[0],v[1]] if len(v)==2 else [v[0],v[1],v[2],v[1]] if len(v)==3 else v
                styles.update(dict(zip(['padding-'+x for x in ('top','right','bottom','left')],vals)))
        # Do not infer complex background shorthand. Keep one protected module if needed.
        pf={'styles':styles}
        warnings.append('旧模板缺少测量的全文格式；只能使用原 HTML 中已有的值，不猜测浏览器计算值。')
    if not isinstance(pf.get('styles'),dict):raise LayoutError('全文格式 styles 无效')
    if set(pf['styles'])-set(PAGE_PROPERTIES):raise LayoutError('全文格式含插件不认识的属性')
    modules=top_modules(root)
    if not modules:
        children=[c for c in root.children if not c.tag.startswith('#')]
        modules=children if len(children)>1 and root.tag!='svg' and not any(c.tag=='#text' and c.text.strip() for c in root.children) else [root]
        if 'background' in css_parse(root.attrs.get('style','')) and not any(k.startswith('background-') for k in pf['styles']):modules=[root]
        warnings.append('模板没有原生顶层标记；已列出保守候选边界，需目视确认。')
    return packet,tree,root,pf,modules,warnings

def analyze(template_path,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    packet,tree,root,pf,mods,warnings=load_template(template_path)
    validate_html(root)
    catalog=[]
    for n in root.walk():
        if n.tag=='#text':
            if n.text.strip():
                catalog.append({'id':n.uid,'type':'text','text':n.text,'parent':n.parent.uid,'parentTag':n.parent.tag,
                 'path':[a.tag for a in reversed(list(ancestors(n))) if a.tag!='#root'],
                 'style':n.parent.attrs.get('style',''),'href':nearest(n,'a').attrs.get('href','') if nearest(n,'a') else '',
                 'svgText':any(a.tag in ('text','tspan','textPath') for a in ancestors(n))})
        elif not n.tag.startswith('#'):
            catalog.append({'id':n.uid,'type':'element','tag':n.tag,'parent':n.parent.uid if n.parent else None,
              'children':[c.uid for c in n.children], 'text':n.plain()[:400],
              'attrs':clean_summary(n.attrs),'hash':digest(n.html()), 'module':n in mods})
    obj={'schema':'opslion-web-template-analysis/v1','templateHash':digest(packet['html']), 'title':packet.get('title',''),
       'inputSchema':packet['schema'],'root':root.uid,'moduleCandidates':[n.uid for n in mods],'pageFormat':pf,
       'warnings':warnings,'nodes':catalog}
    write_json(out/'template.analysis.json',obj)
    write_json(out/'template.raw.json',packet)
    body=root.html()
    (out/'template.preview.html').write_text(preview(body,packet.get('title','模板'),{}),encoding='utf-8')
    return obj

def preview(body,title,styles):
    return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; img-src https: http: data:; style-src \'unsafe-inline\'; font-src data:; base-uri \'none\'; form-action \'none\'"><title>'+escape(title)+'</title></head><body style="margin:0;background:#f1f3f5"><main id="article-preview" style="max-width:375px;margin:0 auto;box-sizing:border-box;'+escape(css_string(styles),quote=True)+'">'+body+'</main></body></html>'

def prepare(template,paths,out):
    out=Path(out)
    if (out/'materials.json').exists():raise LayoutError('工作目录已有原材料，请为新任务使用新目录，或使用 extend 补充材料')
    a=analyze(template,out);m=ingest(paths);write_json(out/'materials.json',m);write_json(out/'materials.summary.json',clean_summary(m))
    assets=out/'assets';assets.mkdir(exist_ok=True)
    for x in m['assets']:
        extension={'image/png':'.png','image/jpeg':'.jpg','image/gif':'.gif','image/webp':'.webp','image/avif':'.avif'}[x['mime']]
        (assets/(x['id']+extension)).write_bytes(base64.b64decode(x['src'].split(',',1)[1]))
    # No fake semantic mapping: starter is deliberately incomplete and cannot build.
    plan={'schema':SCHEMA,'templateHash':a['templateHash'],'materialsHash':m['hash'],'title':'',
       'mode':'new-article','operations':[], 'templateRetain':{},'imageRetain':{},'sourceDispositions':{},
       'assetDispositions':{},'issueResolutions':{},'unresolved':[], 'moduleBoundaries':a['moduleCandidates']}
    write_json(out/'plan.starter.json',plan)
    return {'workspace':str(out),'templateNodes':len(a['nodes']),'sourceBlocks':len(m['blocks']),'images':len(m['assets']),'issues':len(m['issues'])}

def extend_workspace(workspace,paths,out):
    """Append a new submission revision without renumbering existing source IDs."""
    ws=Path(workspace);out=Path(out)
    if ws.resolve()==out.resolve() or (out.exists() and any(out.iterdir())):raise LayoutError('extend 需要一个新的空工作目录')
    old=read_json(ws/'materials.json');h=old.pop('hash')
    if digest(old)!=h:raise LayoutError('旧工作包材料哈希不一致')
    i=Ingest();i.files=old['files'];i.blocks=old['blocks'];i.assets=old['assets'];i.issues=old['issues']
    i._asset_hash={a['sha256']:a for a in i.assets};i.total=sum(f['bytes'] for f in i.files)
    for path in paths:
        p=Path(path)
        if not p.is_file() or p.stat().st_size>MAX_FILE:raise LayoutError('新增材料路径无效或过大')
        i.visit(p.name,p.read_bytes())
    m=i.result();out.mkdir(parents=True,exist_ok=True)
    for name in ('template.raw.json','template.analysis.json'):
        (out/name).write_bytes((ws/name).read_bytes())
    write_json(out/'materials.json',m);write_json(out/'materials.summary.json',clean_summary(m))
    for a in m['assets']:
        ext={"image/png":'.png',"image/jpeg":'.jpg',"image/gif":'.gif',"image/webp":'.webp',"image/avif":'.avif'}[a['mime']]
        dest=out/'assets'/(a['id']+ext);dest.parent.mkdir(exist_ok=True);dest.write_bytes(base64.b64decode(a['src'].split(',',1)[1]))
    pp=ws/'layout.plan.json'
    if not pp.exists():pp=ws/'plan.starter.json'
    if pp.exists():
        plan=read_json(pp);plan['materialsHash']=m['hash'];write_json(out/'layout.plan.json',plan)
    return {'workspace':str(out),'materialsHash':m['hash'],'sourceBlocks':len(m['blocks']),'assets':len(m['assets']),'note':'原有 ID 保持不变。新增材料仍须映射与分类，不代表自动应用。'}

def is_web_url(value):
    try:
        u=urlparse(value);return u.scheme in ('http','https') and bool(u.hostname) and not u.username and not u.password
    except ValueError:return False

def safe_resource(src,manifest):
    if src.startswith('#'):return src
    if src.startswith('opslion-asset://'):
        aid=src[16:]
        if aid not in manifest:raise LayoutError('素材 token 未绑定: '+aid)
        src=manifest[aid]
    if src.startswith('data:'):
        if not re.fullmatch(r'data:image/(?:png|jpe?g|gif|webp|avif);base64,[A-Za-z0-9+/=\s]+',src):raise LayoutError('不支持的 data 图片')
        try:raw=base64.b64decode(src.split(',',1)[1],validate=True)
        except Exception:raise LayoutError('图片 Base64 损坏')
        suffix={'image/png':'.png','image/jpg':'.jpg','image/jpeg':'.jpg','image/gif':'.gif','image/webp':'.webp','image/avif':'.avif'}[src[5:].split(';',1)[0]]
        image_info(raw,suffix)
    elif not is_web_url(src) or urlparse(src).hostname in ('localhost','127.0.0.1','::1'):
        raise LayoutError('不可交付的素材路径: '+src[:160])
    return src

def validate_html(root,manifest=None):
    manifest=manifest or {};ids=[];refs=[];images=[]
    bad=set('script iframe object embed form input button style link meta base audio video canvas textarea select'.split())
    for n in root.walk():
        if n.tag.lower() in bad:raise LayoutError('模板含 Bridge 不支持的活动内容: '+n.tag)
        if 'id' in n.attrs:ids.append(n.attrs['id'])
        for k,v in n.attrs.items():
            if re.match(r'^on',k,re.I):raise LayoutError('模板包含脚本事件属性')
            if k in ('href','xlink:href') and n.tag=='a' and v and not is_web_url(v):raise LayoutError('链接非 HTTP(S): '+v[:100])
            if k=='style':
                if BAD_STYLE.search(v):raise LayoutError('模板含插件拒绝的 CSS 表达式；不得静默删除样式')
                for match in URL_RE.finditer(v):
                    s=match[2]
                    if s.startswith('#'):refs.append(s[1:])
                    else:images.append(safe_resource(s,manifest))
            elif 'url(' in v:
                for match in URL_RE.finditer(v):
                    if match[2].startswith('#'):refs.append(match[2][1:])
                    else:raise LayoutError('SVG 绘制属性不允许外部资源')
        if n.tag=='img':
            if n.attrs.get('src'):images.append(safe_resource(n.attrs['src'],manifest))
            else:raise LayoutError('存在未绑定 src 的图片')
        if n.tag=='image':
            for k in ('href','xlink:href'):
                if n.attrs.get(k):images.append(safe_resource(n.attrs[k],manifest))
        if n.tag in ('use','textPath','linearGradient','radialGradient','pattern'):
            for k in ('href','xlink:href'):
                if k in n.attrs:
                    if not n.attrs[k].startswith('#'):raise LayoutError('SVG 不允许外部引用')
                    refs.append(n.attrs[k][1:])
        if n.tag in ('animate','animateTransform','set'):
            target=n.attrs.get('attributeName','')
            if target not in ('viewBox','height','width','x','y','opacity','transform','visibility'):raise LayoutError('SVG 动画属性超出 Bridge 0.4 的允许范围: '+target)
            if 'href' in n.attrs or 'xlink:href' in n.attrs:raise LayoutError('不支持跨节点动画目标')
            for k in ('begin','end'):
                refs.extend(re.findall(r'(?:^|;)\s*([\w:.-]+)\.(?:click|touchstart|touchend|begin|end|mousedown|mouseup|mouseenter|mouseleave|pointerdown|pointerup)\b',n.attrs.get(k,'')))
    duplicates=[k for k,c in Counter(ids).items() if c>1]
    if duplicates:raise LayoutError('重复 HTML/SVG ID: '+', '.join(duplicates[:5]))
    missing=set(refs)-set(ids)
    if missing:raise LayoutError('SVG 引用缺失: '+', '.join(sorted(missing)[:5]))
    return images

def scalar_range(part,b):
    start=part.get('start',0);end=part.get('end',len(b['text']))
    if not isinstance(start,int) or not isinstance(end,int) or not 0<=start<end<=len(b['text']):raise LayoutError('来源字符区间无效；区间按 Python Unicode 字符计数')
    return start,end

def source_runs(b,start,end):
    pos=0;out=[]
    for r in b.get('runs',[]) or [{'text':b['text']}]:
        t=r['text'];lo=max(start,pos);hi=min(end,pos+len(t))
        if hi>lo:out.append({**r,'text':t[lo-pos:hi-pos]})
        pos+=len(t)
    if ''.join(r['text'] for r in out)!=b['text'][start:end]:raise LayoutError('来源 runs 与原文不一致')
    return out

def render_run(run,svg=False,existing_anchor=None):
    text=run['text'];href=run.get('href','')
    if href and not is_web_url(href):raise LayoutError('来源链接无效，需先处理: '+href)
    if svg:
        if '\n' in text:raise LayoutError('原生 SVG 文字不可自动换行；须按已有 tspan 逐段映射')
        if href and not existing_anchor:raise LayoutError('原生 SVG 链接不能按 HTML 方式自动创建')
        return [Node(text=text,uid='new-text')]
    items=[]
    for i,line in enumerate(text.split('\n')):
        if i:items.append(Node('br',uid='new-br'))
        n=Node(text=line,uid='new-text')
        for key,tag in [('bold','strong'),('italic','em'),('underline','u'),('strike','s')]:
            if run.get(key):w=Node(tag,uid='new-mark');w.add(n);n=w
        if run.get('vertical') in ('superscript','subscript'):
            w=Node('sup' if run['vertical']=='superscript' else 'sub',uid='new-mark');w.add(n);n=w
        if href and not existing_anchor:
            w=Node('a',{'href':href,'target':'_blank','rel':'noopener noreferrer','style':'color:inherit;text-decoration:inherit'},uid='new-link');w.add(n);n=w
        items.append(n)
    return items

class Compiler:
    def __init__(self,workspace,plan):
        self.ws=Path(workspace);self.plan=plan;self.m=read_json(self.ws/'materials.json')
        self.packet,self.tree,self.root,self.pf,self.modules,self.warnings=load_template(self.ws/'template.raw.json')
        if plan.get('schema')!=SCHEMA:raise LayoutError('排版计划 schema 错误')
        if plan.get('templateHash')!=digest(self.packet['html']):raise LayoutError('模板已改变；不能应用过期计划')
        mh=self.m.pop('hash');actual=digest(self.m);self.m['hash']=mh
        if mh!=actual or plan.get('materialsHash')!=mh:raise LayoutError('原始提取材料已改变；不能应用过期计划')
        self.blocks={b['id']:b for b in self.m['blocks']};self.assets={a['id']:a for a in self.m['assets']}
        self.used_ranges=[];self.used_images=[];self.used_assets=[];self.log=[];self.new_sources={}
        self.original={n.uid:n.clone() for n in self.root.walk()}
        self.seq=0;self.replaced_images=set();self.numbered=set()
    def explanation(self,item,name):
        if not isinstance(item,dict) or not item.get('reason'):raise LayoutError(name+' 必须有原因')
    def build(self):
        if self.plan.get('unresolved'):raise LayoutError('仍有未解决事项: '+str(self.plan['unresolved'])[:500])
        for q in self.m['issues']:
            r=self.plan.get('issueResolutions',{}).get(q['id'])
            if q['blocking'] and not r:raise LayoutError('材料问题未处理 '+q['id']+': '+q['message'])
            if r:
                if not r.get('action') or not r.get('evidence'):raise LayoutError('问题处理须有 action 和 evidence')
                self.log.append({'kind':'issue-resolution','issue':q, 'decision':r})
        # User additions/edits never overwrite source material records.
        for b in self.plan.get('userAdditions',[]):
            if not b.get('id','').startswith('U') or b['id'] in self.blocks or not b.get('evidence') or not isinstance(b.get('text'),str):raise LayoutError('人工增补须有 U 前缀唯一 ID、原文和授权依据')
            b={**b,'kind':'text','runs':b.get('runs') or [{'text':b['text']}]}
            self.blocks[b['id']]=b;self.new_sources[b['id']]=b
        self.apply(self.root,self.plan.get('operations',[]),'root')
        for n in self.root.walk():
            if n.tag=='#text' and n.text.strip() and n.uid in self.original:
                d=self.plan.get('templateRetain',{}).get(n.uid)
                if not d or d.get('role') not in ('decoration','permanent-brand','user-authorized-reuse') or not d.get('reason'):
                    raise LayoutError('仍有旧模板文字未分类/替换: '+n.uid+' '+n.text[:70])
            if ((n.tag in ('img','image') and not getattr(n,'image_replaced',False)) or URL_RE.search(n.attrs.get('style',''))) and n.uid in self.original:
                # Replacement state is per instance; backgrounds always require a retain decision.
                d=self.plan.get('imageRetain',{}).get(n.uid)
                if not d or d.get('role') not in ('decoration','user-authorized-reuse') or not d.get('reason'):
                    raise LayoutError('旧模板图片/背景未确认用途: '+n.uid)
        for bid,b in self.blocks.items():
            disp=self.plan.get('sourceDispositions',{}).get(bid)
            if b['kind']=='image':
                n=self.used_images.count(bid)
                if n==0 and not disp:raise LayoutError('正文图片未安放: '+bid)
                if n>1 and not self.plan.get('duplicateSources',{}).get(bid):raise LayoutError('同一图片出现重复绑定: '+bid)
            elif b['text']:
                used=[(s,e) for x,s,e in self.used_ranges if x==bid]
                marks=[0]*len(b['text'])
                for s,e in used:
                    for i in range(s,e):marks[i]+=1
                if any(c>1 for c in marks) and not self.plan.get('duplicateSources',{}).get(bid):raise LayoutError('正文重复使用: '+bid)
                if any(c==0 and not b['text'][i].isspace() for i,c in enumerate(marks)) and not disp:
                    raise LayoutError('正文未完整排入: '+bid+' '+b['text'][:70])
                if b.get('numbering') and used and bid not in self.numbered:raise LayoutError('编号段落未保留编号: '+bid)
                if disp and used:raise LayoutError('不允许同时使用和排除同一块；需要先拆分来源: '+bid)
            if disp:
                if disp.get('action') not in ('instruction','image-anchor','superseded','user-excluded') or not disp.get('reason') or not disp.get('evidence'):raise LayoutError('来源排除必须有明确分类、原因和依据: '+bid)
                self.log.append({'kind':'source-disposition','source':bid,'decision':disp})
        for aid,a in self.assets.items():
            if aid not in self.used_assets:
                d=self.plan.get('assetDispositions',{}).get(aid)
                if not d or not d.get('reason'):raise LayoutError('尚有未使用素材未说明去向: '+aid)
        # Validate before HTML is ever handed to a browser.
        validate_html(self.root)
        boundary_ids=self.plan.get('moduleBoundaries') or [n.uid for n in self.modules]
        targets=[n for n in self.root.walk() if n.uid in boundary_ids]
        for n in targets:
            if any(a in targets for a in ancestors(n)):raise LayoutError('模块边界相互嵌套')
        if not targets:targets=[self.root]
        natives=partition(self.root,targets,self.pf['styles'])
        combined=Node('#root')
        for n in natives:combined.add(n)
        validate_html(combined)
        title=self.plan.get('title')
        if not isinstance(title,str) or not title.strip():raise LayoutError('请从原文明确填写文章标题')
        result=make_packet(self.root,natives,self.pf,title)
        check_packet(result)
        review={'schema':'opslion-web-review/v1','templateHash':self.plan['templateHash'],'materialsHash':self.plan['materialsHash'],
          'protocol':'xiumi-bridge/v3','modules':len(natives),'sourceBlocks':len(self.blocks),'assets':len(result['assets']),
          'sourceCoverage':'complete-or-explicitly-classified','templateExecution':'DOM operations only; no arbitrary CSS or HTML',
          'localChecksPassed':True,'browserCheck':'not-run','realXiumiSave':'not-tested',
          'changes':self.log,'sourceRanges':self.used_ranges,'imageUses':self.used_images,
          'warnings':self.warnings,'sourceFiles':self.m['files'], 'template':self.packet.get('title','')}
        return result,review
    def apply(self,scope,ops,context):
        if not isinstance(ops,list):raise LayoutError('operations 必须为数组')
        for op in ops:
            kind=op.get('op');target=op.get('target');n=get_node(scope,target)
            if kind=='text':
                if n.tag!='#text' or op.get('expected')!=n.text:raise LayoutError('文字槽位/原文不匹配: '+str(target))
                parts=op.get('parts',[]);runs=[];newtext=''
                if not parts and not op.get('reason'):raise LayoutError('清空文字须有原因')
                for part in parts:
                    bid=part.get('source');b=self.blocks.get(bid)
                    if not b or b['kind']=='image':raise LayoutError('引用的文字来源不存在: '+str(bid))
                    s,e=scalar_range(part,b);rr=source_runs(b,s,e)
                    if b.get('numbering') and s==0:
                        nd=self.plan.get('numberingDecisions',{}).get(bid)
                        if not nd or not nd.get('reason'):raise LayoutError('编号段落须有 numberingDecisions: '+bid)
                        if nd.get('mode')=='prefix':
                            display=b['numbering'].get('display') or nd.get('display')
                            if not display:raise LayoutError('编号缺少可靠可见标号: '+bid)
                            rr=[{'text':display+' '}]+rr
                        elif nd.get('mode')=='template-native':
                            li=nearest(n,'li');lst=next((a for a in ancestors(n) if a.tag in ('ol','ul')),None)
                            if not li or not lst:raise LayoutError('原生编号模式要求位于原模板 li 内')
                            if b['numbering'].get('format')=='decimal':
                                items=[x for x in lst.children if x.tag=='li']
                                if lst.tag!='ol' or int(lst.attrs.get('start','1'))+items.index(li)!=b['numbering']['number']:raise LayoutError('原生列表起始编号与来源不符')
                        else:raise LayoutError('编号模式只支持 prefix/template-native')
                        self.numbered.add(bid)
                    runs.extend(rr);self.used_ranges.append((bid,s,e));newtext+=''.join(r['text'] for r in rr)
                svg=any(a.tag in ('text','tspan','textPath') for a in ancestors(n))
                anchor=nearest(n,'a');hrefs={r.get('href','') for r in runs}
                # Anchors are changed only if this operation covers their entire text.
                if anchor:
                    if len(hrefs)>1:raise LayoutError('模板一个链接槽对应多个目标，请分拆源/模板范围')
                    target_href=next(iter(hrefs),'')
                    if anchor.plain()!=n.text and target_href!=anchor.attrs.get('href',''):raise LayoutError('链接横跨多个样式叶节点；请用 link 操作一次更新完整 anchor')
                    if anchor.plain()==n.text:
                        if target_href:anchor.attrs['href']=target_href
                        else:anchor.attrs.pop('href',None)
                nodes=[]
                for r in runs:nodes.extend(render_run(r,svg,anchor))
                replace_node(n,nodes)
                self.log.append({'kind':'text','context':context,'target':target,'before':n.text,'after':newtext,'parts':parts})
            elif kind=='link':
                if n.tag!='a' or op.get('expectedHref','')!=n.attrs.get('href',''):raise LayoutError('链接元素/旧地址不匹配')
                source=op.get('source');href=op.get('href','')
                links={r.get('href') for r in self.blocks.get(source,{}).get('runs',[]) if r.get('href')}
                if href and (not is_web_url(href) or (href not in links and not op.get('userEvidence'))):raise LayoutError('新链接没有来源或人工授权')
                if not href and not op.get('reason'):raise LayoutError('移除链接须有原因')
                if href:n.attrs['href']=href
                else:n.attrs.pop('href',None)
                self.log.append({'kind':'link','context':context,'target':target,'before':op.get('expectedHref',''),'after':href})
            elif kind=='image':
                if n.tag not in ('img','image'):raise LayoutError('图片替换只能指向 img / SVG image')
                aid=op.get('asset');a=self.assets.get(aid)
                if not a:raise LayoutError('图片素材不存在: '+str(aid))
                bid=op.get('source');b=self.blocks.get(bid)
                if bid and (not b or b['kind']!='image' or (b.get('assetId') and b['assetId']!=aid)):raise LayoutError('图片出现位置与素材不匹配')
                if not bid and not op.get('evidence'):raise LayoutError('外置素材与位置绑定必须提供依据')
                if bid:self.used_images.append(bid)
                self.used_assets.append(aid)
                for k in ['src'] if n.tag=='img' else (['href','xlink:href'] if 'xlink:href' in n.attrs else ['href']):n.attrs[k]=a['src']
                n.attrs.pop('srcset',None)
                if op.get('alt') is not None:n.attrs['alt']=str(op['alt'])
                n.image_replaced=True
                self.log.append({'kind':'image','context':context,'target':target,'asset':aid,'source':bid})
            elif kind=='repeat':
                if n is scope or n.tag.startswith('#'):raise LayoutError('repeat 必须选择一个完整子区域而非当前根/文字')
                self.explanation(op,'repeat')
                instances=op.get('instances',[])
                if not 1<=len(instances)<=500:raise LayoutError('repeat 实例数需为 1..500')
                clones=[]
                for i,inst in enumerate(instances):
                    c=n.clone();self.seq+=1
                    self.apply(c,inst.get('operations',[]),context+'/'+target+':'+str(i+1))
                    scope_clone_ids(c,'copy'+str(self.seq));clones.append(c)
                replace_node(n,clones);self.log.append({'kind':'repeat','target':target,'instances':len(clones),'reason':op['reason']})
            elif kind=='remove':
                if n is scope or n.tag.startswith('#'):raise LayoutError('remove 须指向完整子区域，清空文字用 text')
                self.explanation(op,'remove')
                if op.get('expectedHash')!=digest(n.html()):raise LayoutError('删除区域哈希不匹配')
                self.log.append({'kind':'remove','target':target,'before':n.plain(),'reason':op['reason']});replace_node(n,[])
            else:raise LayoutError('不允许的操作；不能任意改 CSS/HTML: '+str(kind))

def make_packet(root,natives,pf,title):
    # Manifest covers the FINAL native modules AND page-level backgrounds.
    assets=[];by_src={}
    def add(src,kind):
        if not src or src.startswith('#'):return
        if src in by_src:by_src[src]['occurrences']+=1;return
        safe_resource(src,{})
        status='embedded' if src.startswith('data:') else 'remote'
        a={'id':'asset-'+str(len(assets)+1),'src':src,'kind':kind,'occurrences':1,'status':status,
           'bytes':len(base64.b64decode(src.split(',',1)[1])) if status=='embedded' else 0}
        assets.append(a);by_src[src]=a
    for n in [e for r in natives for e in r.walk()]:
        if n.tag=='img':add(n.attrs.get('src',''),'image')
        if n.tag=='image':
            for key in ('href','xlink:href'):add(n.attrs.get(key,''),'image')
        for m in URL_RE.finditer(n.attrs.get('style','')):add(m[2],'background')
    for v in pf['styles'].values():
        for m in URL_RE.finditer(v):add(m[2],'background')
    def compact(s):
        for a in assets:
            if a['status']=='embedded':s=s.replace(a['src'],'opslion-asset://'+a['id'])
        return s
    # Preview html assembled from the same modules / page format as import, not a second rendering.
    native_html=''.join(n.html() for n in natives)
    styles={k:compact(v) for k,v in pf['styles'].items()}
    full='<section style="'+escape(css_string(pf['styles']),quote=True)+'">'+native_html+'</section>'
    return {'schema':'xiumi-bridge/v3','title':title,'html':compact(full),'plainText':root.plain(),
       'generatedAt':datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),
       'native':{'modules':[{'id':'module-'+str(i+1),'html':compact(n.html())} for i,n in enumerate(natives)],
          'pageFormat':{**pf,'styles':styles}},'assets':assets,
       'assetSummary':{'embedded':sum(a['status']=='embedded' for a in assets),'embeddedBytes':sum(a['bytes'] for a in assets),'local':0},
       'patch':{'available':False,'operations':[],'reasons':['此文件用于分模块导入空白图文。不要原位覆盖历史母版；在秀米保存并重新打开后核验。']}}

def check_packet(p):
    if p.get('schema')!='xiumi-bridge/v3' or not p.get('html','').strip():raise LayoutError('缺少 Bridge v3 正文')
    mods=p.get('native',{}).get('modules')
    if not isinstance(mods,list) or not 1<=len(mods)<=5000:raise LayoutError('原生模块数错误')
    if len({m['id'] for m in mods})!=len(mods):raise LayoutError('模块 ID 重复')
    aa=p.get('assets')
    if not isinstance(aa,list) or len({a['id'] for a in aa})!=len(aa):raise LayoutError('素材清单/ID 无效')
    manifest={a['id']:a['src'] for a in aa}
    for a in aa:safe_resource(a['src'],{})
    styles=p['native'].get('pageFormat',{}).get('styles',{})
    if set(styles)-set(PAGE_PROPERTIES) or any(not isinstance(v,str) for v in styles.values()):raise LayoutError('全文格式不兼容')
    holder=Node('section',{'style':css_string(styles)})
    for m in mods:
        if not m.get('html','').strip():raise LayoutError('存在空模块')
        for n in parse_html(m['html']).children:holder.add(n)
    validate_html(holder,manifest)
    # Reject modules before large upload operations; adapter's hard post-upload limit is 1.5M chars.
    size=sum(len(m['html']) for m in mods)
    if size>1_350_000:raise LayoutError('模块 HTML 过大，接近插件 1,500,000 字符写入上限；不能通过整篇合框绕过')
    full=parse_html(p['html']);validate_html(full,manifest)
    expected='<section style="'+escape(css_string(styles),quote=True)+'">'+''.join(m['html'] for m in mods)+'</section>'
    if full.html()!=parse_html(expected).html():raise LayoutError('预览 HTML 与实际导入模块不一致')
    return {'ok':True,'modules':len(mods),'assets':len(aa),'htmlChars':size}

def expanded_html(p):
    manifest={a['id']:a['src'] for a in p['assets']}
    return re.sub(r'opslion-asset://([A-Za-z0-9_-]+)',lambda m:manifest[m[1]],p['html'])

def review_html(p,report,materials):
    rows=[]
    for c in report['changes']:
        if c['kind'] in ('text','link'):
            rows.append('<tr><td>'+escape(c['context']+'/'+c['target'])+'</td><td>'+escape(c.get('before',''))+'</td><td>'+escape(c.get('after',''))+'</td></tr>')
    asset={a['id']:a for a in materials['assets']};src=[]
    for b in materials['blocks']:
        if b['kind']=='image':
            a=asset.get(b.get('assetId'))
            content=('<img style="max-width:220px;max-height:160px" src="'+escape(a['src'],quote=True)+'">') if a else '[图片未解析]'
        else:
            content=''.join(n.html() for r in (b.get('runs') or [{'text':b.get('text','')}]) for n in render_run({k:v for k,v in r.items() if k!='href' or is_web_url(str(v))}))
        src.append('<tr><td>'+escape(b['id'])+'</td><td>'+escape(str(b.get('file','')))+'</td><td>'+content+'</td></tr>')
    finalroot=parse_html(p['html'])
    links=''.join('<tr><td>'+escape(n.plain())+'</td><td>'+escape(n.attrs.get('href',''))+'</td></tr>' for n in finalroot.walk() if n.tag=='a' and n.attrs.get('href'))
    photos=''.join('<figure><img style="max-width:260px;max-height:200px" src="'+escape(a['src'],quote=True)+'"><figcaption>'+escape(a['id']+' / '+a['kind'])+'</figcaption></figure>' for a in p['assets'])
    return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src &#39;none&#39;; img-src https: http: data:; style-src &#39;unsafe-inline&#39;; base-uri &#39;none&#39;; form-action &#39;none&#39;"><title>排版检查记录</title></head><body style="font-family:system-ui;line-height:1.7;margin:28px"><h1>'+escape(p['title'])+' · 排版检查记录</h1><p>本文件记录文字、链接、素材来源与程序检查结果，不是秀米导入文件。实际版面见 preview.html；仅声明已经执行的检查。</p><h2>文字/链接变更</h2><table border="1" cellpadding="8"><tr><th>位置</th><th>旧模板</th><th>本次成稿</th></tr>'+''.join(rows)+'</table><h2>最终链接地址（不是旧稿地址）</h2><table border="1" cellpadding="8"><tr><th>显示文字</th><th>目标地址</th></tr>'+links+'</table><h2>最终素材</h2>'+photos+'<h2>来源原文及配图（按提取顺序）</h2><table border="1" cellpadding="8"><tr><th>来源 ID</th><th>文件 ID</th><th>原内容</th></tr>'+''.join(src)+'</table><h2>来源处置与检查记录</h2><pre style="white-space:pre-wrap">'+escape(json.dumps(clean_summary(report),ensure_ascii=False,indent=2))+'</pre></body></html>'

def compile_workspace(ws,planfile,out):
    ws=Path(ws);out=Path(out)
    if (out/'article.xiumi.json').exists():raise LayoutError('输出目录已有成稿；请为新修订使用新的输出目录，防止误交旧文件')
    out.mkdir(parents=True,exist_ok=True);plan=read_json(planfile)
    # Legacy approval bookkeeping is not part of a layout plan or delivery contract.
    plan.pop('review',None)
    comp=Compiler(ws,plan);packet,report=comp.build()
    write_json(out/'article.xiumi.json',packet);write_json(out/'validation.json',report)
    (out/'preview.html').write_text(preview(expanded_html(packet),packet['title'],{}),encoding='utf-8')
    (out/'review.html').write_text(review_html(packet,report,comp.m),encoding='utf-8')
    write_json(out/'layout.plan.json',plan)
    with zipfile.ZipFile(out/'work.zip','w',zipfile.ZIP_DEFLATED) as z:
        for name in ['template.raw.json','template.analysis.json','materials.json','materials.summary.json']:
            z.write(ws/name,'workspace/'+name)
        z.writestr('workspace/layout.plan.json',json.dumps(plan,ensure_ascii=False,indent=2))
        for name in ['article.xiumi.json','preview.html','review.html','validation.json']:z.write(out/name,'output/'+name)
    return check_packet(packet)

def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    a=sub.add_parser('prepare');a.add_argument('--template',required=True);a.add_argument('--materials',nargs='+',required=True);a.add_argument('--out',required=True)
    a=sub.add_parser('extend');a.add_argument('--workspace',required=True);a.add_argument('--materials',nargs='+',required=True);a.add_argument('--out',required=True)
    a=sub.add_parser('analyze-template');a.add_argument('--template',required=True);a.add_argument('--out',required=True)
    a=sub.add_parser('build');a.add_argument('--workspace',required=True);a.add_argument('--plan',required=True);a.add_argument('--out',required=True)
    a=sub.add_parser('validate');a.add_argument('packet')
    args=p.parse_args()
    try:
        if args.command=='prepare':res=prepare(args.template,args.materials,args.out)
        elif args.command=='extend':res=extend_workspace(args.workspace,args.materials,args.out)
        elif args.command=='analyze-template':res=analyze(args.template,args.out)
        elif args.command=='build':res=compile_workspace(args.workspace,args.plan,args.out)
        else:res=check_packet(read_json(args.packet))
        print(json.dumps(clean_summary(res),ensure_ascii=False,indent=2))
    except (LayoutError,ValueError,KeyError,OSError,zipfile.BadZipFile) as e:
        print(json.dumps({'ok':False,'error':str(e)},ensure_ascii=False),file=sys.stderr);return 2
    return 0
if __name__=='__main__':sys.exit(main())
