#!/usr/bin/env python3
"""Optional real Chromium verification and screenshots. Never authenticates to Xiumi.
Requires installed Playwright + Chromium; core compiler does not require either.
"""
import argparse,json,shutil,sys,re
from pathlib import Path
from urllib.parse import urlparse
from xiumi_skill import read_json,write_json,check_packet,expanded_html,preview
from xiumi_dom import LayoutError

def browser_check(packet_path,out,allow_remote=False):
    from playwright.sync_api import sync_playwright
    p=read_json(packet_path);check_packet(p);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    executable=shutil.which('chromium') or shutil.which('chromium-browser') or shutil.which('google-chrome')
    blocked=[];reports=[]
    body=preview(expanded_html(p),p['title'],{})
    with sync_playwright() as pw:
        options={'headless':True,'args':['--no-sandbox']}
        if executable:options['executable_path']=executable
        browser=pw.chromium.launch(**options)
        for width in (375,430):
            page=browser.new_page(viewport={'width':width,'height':900},device_scale_factor=1)
            def route(r):
                u=urlparse(r.request.url)
                host=(u.hostname or '').lower()
                private=(host in ('localhost','::1') or bool(re.match(r'^(?:127\.|10\.|192\.168\.|169\.254\.|172\.(?:1[6-9]|2\d|3[01])\.)',host)))
                if u.scheme in ('data','about') or (allow_remote and u.scheme=='https' and not private and r.request.resource_type=='image'):r.continue_()
                else:blocked.append(r.request.url);r.abort()
            page.route('**/*',route)
            page.set_content(body,wait_until='load');page.wait_for_timeout(500)
            # Enlarge the PREVIEW viewport's allowed article width; never change packet layout.
            page.locator('#article-preview').evaluate('(e,w)=>e.style.maxWidth=w+"px"',width)
            audit=page.evaluate('''() => {
              const root=document.querySelector('#article-preview');
              const elements=[...root.querySelectorAll('*')];
              const brokenImages=elements.filter(e=>e.tagName==='IMG' && (!e.complete || !e.naturalWidth)).map(e=>e.getAttribute('src'));
              const overflow=elements.filter(e=>e.getBoundingClientRect().width>0 && e.scrollWidth>e.clientWidth+3 && e.clientWidth>0 && !['inline','contents'].includes(getComputedStyle(e).display)).map(e=>({tag:e.tagName,text:(e.textContent||'').slice(0,80),client:e.clientWidth,scroll:e.scrollWidth,overflow:getComputedStyle(e).overflow}));
              const active=elements.filter(e=>['SCRIPT','IFRAME','OBJECT','STYLE','LINK'].includes(e.tagName));
              const foreignObjects=elements.filter(e=>e.localName==='foreignObject').length;
              return {height:Math.ceil(root.getBoundingClientRect().height),brokenImages,overflow,activeCount:active.length,foreignObjects,text:root.textContent};
            }''')
            if audit['height']>120000:raise LayoutError('预览高度异常，停止截图')
            page.screenshot(path=str(out/f'preview-{width}.png'),full_page=True)
            h=max(1,audit['height']);tiles=[]
            for y in range(0,h,1600):
                name=f'preview-{width}-y{y:05}.png'
                page.screenshot(path=str(out/name),clip={'x':0,'y':y,'width':width,'height':min(1600,h-y)})
                tiles.append(name)
            reports.append({'width':width,**audit,'tiles':tiles})
            page.close()
        browser.close()
    report={'schema':'opslion-web-browser-check/v1','browser':'Chromium','realXiumiSave':'not-tested','blockedRequests':list(dict.fromkeys(blocked)),
       'viewports':reports,'note':'Overflow entries are candidates: carousels/SVG animations may intentionally overflow. The assistant must inspect all image tiles and correct actionable layout issues; screenshots alone are not a visual-verification result.'}
    write_json(out/'browser-check.json',report)
    return report

def main():
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('packet');a.add_argument('--out',required=True);a.add_argument('--allow-remote',action='store_true');args=a.parse_args()
    try:print(json.dumps(browser_check(args.packet,args.out,args.allow_remote),ensure_ascii=False,indent=2))
    except Exception as e:print(json.dumps({'ok':False,'error':str(e),'visualVerified':False},ensure_ascii=False),file=sys.stderr);return 2
    return 0
if __name__=='__main__':sys.exit(main())
