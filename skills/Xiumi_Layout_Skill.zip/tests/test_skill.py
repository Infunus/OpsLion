"""Local deterministic tests, no model API or authenticated Xiumi traffic."""
import base64,copy,io,json,struct,sys,tempfile,unittest,zipfile,zlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from xiumi_skill import *
from materials import read_zip,Ingest
from xiumi_dom import parse_html,scope_clone_ids


def png(w=32,h=16):
    def chunk(tag,data):return struct.pack('!I',len(data))+tag+data+struct.pack('!I',zlib.crc32(tag+data)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('!2I5B',w,h,8,2,0,0,0))+chunk(b'IDAT',zlib.compress((b'\0'+b'\x6f\x79\x9b'*w)*h))+chunk(b'IEND',b'')

def docx_bytes(body=None,rels='',extras=None):
    pic='<w:p><w:r><w:drawing><a:graphic><a:graphicData><a:blip r:embed="img1"/></a:graphicData></a:graphic></w:drawing></w:r></w:p>'
    b=body or ('<w:p><w:pPr><w:pStyle w:val="Title"/></w:pPr><w:r><w:t>本期活动通知</w:t></w:r></w:p>'
       '<w:p><w:r><w:t>请务必于</w:t></w:r><w:r><w:rPr><w:b/><w:color w:val="C12233"/></w:rPr><w:t>10月1日</w:t></w:r>'
       '<w:r><w:t>前报名。</w:t></w:r><w:hyperlink r:id="link1"><w:r><w:t>查看详情</w:t></w:r></w:hyperlink></w:p>'+pic)
    ns='xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"'
    mem=io.BytesIO()
    with zipfile.ZipFile(mem,'w') as z:
        z.writestr('word/document.xml','<w:document '+ns+'><w:body>'+b+'</w:body></w:document>')
        z.writestr('word/_rels/document.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="img1" Target="media/photo.png" Type="image"/><Relationship Id="link1" Target="https://example.com/new" TargetMode="External" Type="hyperlink"/>'+rels+'</Relationships>')
        z.writestr('word/media/photo.png',png(300,140))
        z.writestr('word/styles.xml','<w:styles '+ns+'><w:style w:styleId="Title"><w:name w:val="Heading 1"/><w:pPr><w:outlineLvl w:val="0"/></w:pPr></w:style></w:styles>')
        for name,value in (extras or {}).items():z.writestr(name,value)
    return mem.getvalue()

def fixture(path):
    path=Path(path);path.mkdir(exist_ok=True,parents=True)
    img='data:image/png;base64,'+base64.b64encode(png(8,8)).decode()
    html='<section style="font-size:14px;line-height:2;color:#24334a;padding:12px;background-color:#fff">'+\
      '<section class="tn-comp-top-level" style="padding:14px;border:1px solid #8782b4"><h1 style="font-size:24px;color:#4f4678">旧标题</h1></section>'+\
      '<section class="tn-comp-top-level" style="margin-top:16px"><p style="line-height:2">旧前缀<strong style="color:#a34b63">旧日期</strong>旧后缀<a href="https://example.com/old" style="color:#4f4678">旧链接</a></p></section>'+\
      '<section class="tn-comp-top-level" style="margin-top:16px"><img style="width:100%;height:auto" src="'+img+'"></section>'+\
      '<section class="tn-comp-top-level"><p style="font-size:12px;text-align:center">固定栏目名称</p></section></section>'
    pf={'styles':{'font-size':'14px','line-height':'28px','color':'rgb(36, 51, 74)','padding-top':'12px','padding-right':'12px','padding-bottom':'12px','padding-left':'12px','background-color':'rgb(255, 255, 255)'}}
    tp={'schema':'opslion-template/v2','title':'严格模板测试母版','sourceType':'xiumi','html':html,'source':{'pageFormat':pf,'modules':[],'capturedAt':'2026-09-11T00:00:00Z'}}
    write_json(path/'raw.opslion-template.json',tp);(path/'稿件.docx').write_bytes(docx_bytes())
    prepare(path/'raw.opslion-template.json',[path/'稿件.docx'],path/'workspace')
    a=read_json(path/'workspace/template.analysis.json');m=read_json(path/'workspace/materials.json');plan=read_json(path/'workspace/plan.starter.json')
    ids={n['text']:n['id'] for n in a['nodes'] if n['type']=='text'}
    title,body,photo=m['blocks'];t=body['text'];cuts=[('旧前缀',0,t.index('10月1日')),('旧日期',t.index('10月1日'),t.index('前报名')),('旧后缀',t.index('前报名'),t.index('查看详情')),('旧链接',t.index('查看详情'),len(t))]
    plan['title']=title['text'];plan['operations']=[{'op':'text','target':ids['旧标题'],'expected':'旧标题','parts':[{'source':title['id']}]}]
    for old,s,e in cuts:plan['operations'].append({'op':'text','target':ids[old],'expected':old,'parts':[{'source':body['id'],'start':s,'end':e}]})
    image=next(n for n in a['nodes'] if n.get('tag')=='img')
    plan['operations'].append({'op':'image','target':image['id'],'asset':photo['assetId'],'source':photo['id']})
    plan['templateRetain']={ids['固定栏目名称']:{'role':'permanent-brand','reason':'示例母版中的固定栏目标识'}}
    write_json(path/'plan.json',plan)
    return path,plan

class TestSkill(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory();self.path,self.plan=fixture(self.temp.name)
    def tearDown(self):self.temp.cleanup()
    def compile(self,plan=None):return Compiler(self.path/'workspace',plan or self.plan).build()
    def test_01_raw_template_protocol(self):
        a=read_json(self.path/'workspace/template.analysis.json');self.assertEqual(a['inputSchema'],'opslion-template/v2');self.assertEqual(len(a['moduleCandidates']),4)
    def test_02_ooxml_links_marks_images(self):
        m=read_json(self.path/'workspace/materials.json');self.assertEqual(len(m['blocks']),3);self.assertEqual(m['blocks'][1]['runs'][1]['text'],'10月1日');self.assertTrue(m['blocks'][1]['runs'][1]['bold']);self.assertEqual(m['blocks'][1]['runs'][-1]['href'],'https://example.com/new')
    def test_03_valid_bridge_packet(self):
        p,r=self.compile();self.assertTrue(check_packet(p)['ok']);self.assertEqual(len(p['native']['modules']),4);self.assertFalse(p['patch']['available']);self.assertEqual(r['realXiumiSave'],'not-tested')
    def test_04_page_format_not_repeated(self):
        p,_=self.compile();self.assertEqual(p['native']['pageFormat']['styles']['padding-left'],'12px');self.assertNotIn('padding:12px',p['native']['modules'][0]['html']);self.assertIn('padding:14px',p['native']['modules'][0]['html'])
    def test_05_strict_template_css(self):
        p,_=self.compile();self.assertIn('color:#a34b63',p['html']);self.assertIn('border:1px solid #8782b4',p['html']);self.assertIn('https://example.com/new',p['html']);self.assertNotIn('https://example.com/old',p['html'])
    def test_06_bitmap_stored_once(self):
        p,_=self.compile();self.assertEqual(p['assetSummary']['embedded'],1);self.assertEqual(json.dumps(p).count('data:image/'),1);self.assertIn('opslion-asset://asset-1',p['html'])
    def test_07_stale_template_fails(self):
        p=copy.deepcopy(self.plan);p['templateHash']='bad'
        with self.assertRaisesRegex(LayoutError,'模板已改变'):self.compile(p)
    def test_08_stale_source_fails(self):
        p=copy.deepcopy(self.plan);p['materialsHash']='bad'
        with self.assertRaisesRegex(LayoutError,'原始提取材料'):self.compile(p)
    def test_09_missing_source_fails(self):
        p=copy.deepcopy(self.plan);p['operations'][0]['parts'][0]['end']=2
        with self.assertRaisesRegex(LayoutError,'正文未完整'):self.compile(p)
    def test_10_stale_template_copy_fails(self):
        p=copy.deepcopy(self.plan);p['templateRetain']={}
        with self.assertRaisesRegex(LayoutError,'旧模板文字'):self.compile(p)
    def test_11_duplicate_source_fails(self):
        p=copy.deepcopy(self.plan);p['operations'][0]['parts']*=2
        with self.assertRaisesRegex(LayoutError,'正文重复'):self.compile(p)
    def test_12_wrong_slot_fails(self):
        p=copy.deepcopy(self.plan);p['operations'][0]['expected']='unknown'
        with self.assertRaisesRegex(LayoutError,'不匹配'):self.compile(p)
    def test_13_css_changes_rejected(self):
        p=copy.deepcopy(self.plan);p['operations'][0]['op']='style'
        with self.assertRaisesRegex(LayoutError,'不允许的操作'):self.compile(p)
    def test_14_missing_image_fails(self):
        p=copy.deepcopy(self.plan);p['operations'][-1]['asset']='A9999'
        with self.assertRaisesRegex(LayoutError,'图片素材不存在'):self.compile(p)
    def test_15_unresolved_blocks_export(self):
        p=copy.deepcopy(self.plan);p['unresolved']=['二维码缺失']
        with self.assertRaisesRegex(LayoutError,'未解决'):self.compile(p)
    def test_16_preview_equals_native(self):
        p,_=self.compile();p['html']='<p>fake</p>'
        with self.assertRaisesRegex(LayoutError,'预览 HTML'):check_packet(p)
    def test_17_missing_manifest_token(self):
        p,_=self.compile();p['assets']=[]
        with self.assertRaisesRegex(LayoutError,'未绑定'):check_packet(p)
    def test_18_script_rejected(self):
        with self.assertRaises(LayoutError):validate_html(parse_html('<section><script>alert(1)</script></section>'))
    def test_19_event_attr_rejected(self):
        with self.assertRaises(LayoutError):validate_html(parse_html('<section onclick="x()">test</section>'))
    def test_20_local_url_rejected(self):
        with self.assertRaises(LayoutError):safe_resource('file:///tmp/a.png',{})
    def test_21_zip_traversal_rejected(self):
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:z.writestr('../evil','hi')
        with self.assertRaises(LayoutError):read_zip(b.getvalue())
    def test_22_docx_zip_nested(self):
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:z.writestr('资料/已审文案.docx',docx_bytes())
        ob=Ingest();ob.visit('材料.zip',b.getvalue());self.assertEqual(len(ob.blocks),3)
    def test_23_svg_foreignobject_case(self):
        t=parse_html('<svg viewBox="0 0 100 100"><foreignObject width="100" height="100"><div xmlns="http://www.w3.org/1999/xhtml">正文</div></foreignObject></svg>');self.assertIn('foreignObject',t.html());self.assertIn('viewBox',t.html())
    def test_24_svg_clone_refs(self):
        t=parse_html('<svg id="s" viewBox="0 0 20 20"><defs><linearGradient id="g"><stop offset="1"/></linearGradient></defs><rect id="r" fill="url(#g)"><animate attributeName="opacity" begin="r.click" from="0" to="1"/></rect></svg>')
        scope_clone_ids(t,'x');self.assertIn('url(#g_x)',t.html());self.assertIn('r_x.click',t.html());validate_html(t)
    def test_25_svg_dangling_rejected(self):
        with self.assertRaises(LayoutError):validate_html(parse_html('<svg><use href="#missing"/></svg>'))
    def test_26_dangerous_animation_rejected(self):
        with self.assertRaises(LayoutError):validate_html(parse_html('<svg><animate attributeName="href" to="https://evil.example"/></svg>'))
    def test_27_user_addition_authorization(self):
        p=copy.deepcopy(self.plan);p['userAdditions']=[{'id':'U1','text':'新增一句'}]
        with self.assertRaisesRegex(LayoutError,'人工增补'):self.compile(p)
    def test_28_full_delivery_and_version_protection(self):
        out=self.path/'delivery';compile_workspace(self.path/'workspace',self.path/'plan.json',out);self.assertTrue((out/'work.zip').exists())
        with self.assertRaises(LayoutError):compile_workspace(self.path/'workspace',self.path/'plan.json',out)
    def test_29_repeat_template_region(self):
        p=copy.deepcopy(self.plan);a=read_json(self.path/'workspace/template.analysis.json');title_op=p['operations'].pop(0);section=next(n for n in a['nodes'] if n.get('module') and '旧标题' in n.get('text',''))
        p['operations'].insert(0,{'op':'repeat','target':section['id'],'reason':'测试复用原模块，不新增 CSS','instances':[{'operations':[title_op]},{'operations':[title_op]}]});p['duplicateSources']={'B00001':{'reason':'测试明确重复标题'}}
        result,_=self.compile(p);self.assertEqual(len(result['native']['modules']),5)
    def test_30_word_table_not_silently_flattened(self):
        b=docx_bytes('<w:tbl><w:tr><w:tc><w:p><w:r><w:t>格一</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>格二</w:t></w:r></w:p></w:tc></w:tr></w:tbl>');i=Ingest();i.visit('t.docx',b);self.assertEqual(len(i.blocks),2);self.assertTrue(any(q['kind']=='table' for q in i.issues));self.assertEqual(i.blocks[1]['column'],2)
    def test_31_source_data_hash(self):
        m=read_json(self.path/'workspace/materials.json');m['blocks'][0]['text']='偷偷修改';write_json(self.path/'workspace/materials.json',m)
        with self.assertRaises(LayoutError):self.compile()
    def test_32_unsupported_input_visible(self):
        i=Ingest();i.visit('旧稿.doc',b'dummy');self.assertTrue(i.issues[0]['blocking'])
    def test_33_duplicate_template_ids(self):
        with self.assertRaises(LayoutError):validate_html(parse_html('<section id="x"><p id="x">x</p></section>'))
    def test_35_asset_id_prefix_does_not_corrupt_preview(self):
        p={'html':'<img src="opslion-asset://asset-10"><img src="opslion-asset://asset-1">','assets':[{'id':'asset-1','src':'https://example.com/1.png'},{'id':'asset-10','src':'https://example.com/10.png'}]}
        self.assertEqual(expanded_html(p),'<img src="https://example.com/10.png"><img src="https://example.com/1.png">')
    def test_36_repeated_image_each_instance_checked(self):
        p=copy.deepcopy(self.plan);a=read_json(self.path/'workspace/template.analysis.json');image_op=p['operations'].pop();target=next(n for n in a['nodes'] if n.get('module') and image_op['target'] in n.get('children',[]))
        p['operations'].append({'op':'repeat','target':target['id'],'reason':'repeat image block','instances':[{'operations':[image_op]},{'operations':[]}]})
        with self.assertRaisesRegex(LayoutError,'旧模板图片'):self.compile(p)
    def test_37_user_addition_compiles_without_mutating_source(self):
        p=copy.deepcopy(self.plan);p['userAdditions']=[{'id':'U1','text':'人工修改后的标题','evidence':'测试中用户明确要求改标题'}];p['sourceDispositions']={'B00001':{'action':'superseded','reason':'人工修订','evidence':'用户要求'}};p['operations'][0]['parts']=[{'source':'U1'}]
        packet,_=self.compile(p);self.assertIn('人工修改后的标题',packet['html']);self.assertEqual(read_json(self.path/'workspace/materials.json')['blocks'][0]['text'],'本期活动通知')
    def test_38_extend_preserves_ids_and_old_text(self):
        write_json(self.path/'workspace/layout.plan.json',self.plan)
        extra=self.path/'补充.txt';extra.write_text('新增信息',encoding='utf-8')
        extend_workspace(self.path/'workspace',[extra],self.path/'workspace-v2')
        m=read_json(self.path/'workspace-v2/materials.json');p=read_json(self.path/'workspace-v2/layout.plan.json')
        self.assertEqual(m['blocks'][0]['id'],'B00001');self.assertEqual(m['blocks'][0]['text'],'本期活动通知');self.assertEqual(m['blocks'][-1]['id'],'B00004');self.assertEqual(p['operations'],self.plan['operations']);self.assertEqual(p['materialsHash'],m['hash'])
        with self.assertRaisesRegex(LayoutError,'正文未完整'):Compiler(self.path/'workspace-v2',p).build()
    def test_39_prepare_never_overwrites_workspace(self):
        with self.assertRaisesRegex(LayoutError,'工作目录已有'):prepare(self.path/'raw.opslion-template.json',[self.path/'稿件.docx'],self.path/'workspace')
    def test_40_raw_template_active_content_rejected_before_preview(self):
        raw=read_json(self.path/'raw.opslion-template.json');raw['html']='<section><script>alert(1)</script><p>正文</p></section>';write_json(self.path/'bad-template.json',raw)
        with self.assertRaises(LayoutError):analyze(self.path/'bad-template.json',self.path/'bad-analysis')
        self.assertFalse((self.path/'bad-analysis/template.preview.html').exists())
    def test_34_bad_base64_rejected(self):
        with self.assertRaises(LayoutError):safe_resource('data:image/png;base64,AAAA',{})

    def test_41_starter_and_report_have_no_approval_workflow(self):
        self.assertNotIn('review',self.plan)
        packet,report=self.compile()
        self.assertTrue(report['localChecksPassed'])
        self.assertEqual(report['browserCheck'],'not-run')
        self.assertEqual(report['realXiumiSave'],'not-tested')
        for key in ('stage','humanFirst','humanSecond'):
            self.assertNotIn(key,report)
        html=review_html(packet,report,read_json(self.path/'workspace/materials.json'))
        self.assertIn('排版检查记录',html)
        self.assertNotIn('待人工',html)
        self.assertNotIn('一校',html)
        self.assertNotIn('二校',html)

    def test_42_legacy_review_metadata_not_exported(self):
        p=copy.deepcopy(self.plan)
        p['review']={'stage':'draft','humanFirst':False,'humanSecond':False}
        write_json(self.path/'legacy.json',p)
        out=self.path/'legacy-delivery'
        compile_workspace(self.path/'workspace',self.path/'legacy.json',out)
        self.assertNotIn('review',read_json(out/'layout.plan.json'))
        with zipfile.ZipFile(out/'work.zip') as z:
            self.assertNotIn('review',json.loads(z.read('workspace/layout.plan.json')))
        report=read_json(out/'validation.json')
        self.assertNotIn('humanFirst',report)
        self.assertTrue(check_packet(read_json(out/'article.xiumi.json'))['ok'])

    def test_43_runtime_instructions_require_self_checks_not_approval(self):
        root=Path(__file__).resolve().parents[1]
        files=[root/'SKILL.md',root/'WEB_START_PROMPT.txt',root/'references/materials-and-quality.md']
        for path in files:
            text=path.read_text(encoding='utf-8')
            self.assertNotIn('一校',text,str(path))
            self.assertNotIn('二校',text,str(path))
            self.assertNotIn('待人工',text,str(path))
        self.assertIn('修正', (root/'SKILL.md').read_text(encoding='utf-8'))
        self.assertIn('完整 Skill ZIP', (root/'SKILL.md').read_text(encoding='utf-8'))

if __name__=='__main__':unittest.main(verbosity=2)
