#!/usr/bin/env python3
"""Exercise UNMODIFIED Bridge 0.4.0 capture/payload/import functions on a synthetic
Xiumi model fixture in real Chromium about:blank with mocked location, SHA-256 and storage. This is NOT a real-account server-save test.
"""
import copy,json,sys,tempfile,shutil,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
sys.path.insert(0,str(Path(__file__).resolve().parent))
from xiumi_skill import *
from test_skill import fixture
from playwright.sync_api import sync_playwright
VENDOR=Path(__file__).parent/'vendor'
def js(name):return (VENDOR/name).read_text().replace('export function ','function ').replace('export async function ','async function ')

def run(out):
    out=Path(out);out.mkdir(exist_ok=True,parents=True);checks=[]
    with tempfile.TemporaryDirectory() as d:
        path,plan=fixture(d);packet,review=Compiler(path/'workspace',plan).build()
        with sync_playwright() as pw:
            exe=shutil.which('chromium') or shutil.which('chromium-browser')
            b=pw.chromium.launch(headless=True,**({'executable_path':exe} if exe else {}),args=['--no-sandbox'])
            page=b.new_page()
            fixture_html='<html><body style="margin:0"><article class="tn-page-inst" tn-comp-role="page" style="font-size:16px"><section class="tn-comp-style-pin" style="font-size:87.5%;line-height:2;letter-spacing:1px;padding:12px;background:#213E71"></section></article></body></html>'
            def setup(opts=None):
                nonlocal page
                page.close(); page=b.new_page()
                page.route('**/*',lambda route:route.abort())
                page.set_content(fixture_html)
                page.expose_function('digestForOfflineTest',lambda data:list(hashlib.sha256(bytes(data)).digest()))
                page.add_script_tag(content="const testStorage={};Object.defineProperty(window,'localStorage',{value:{setItem:(k,v)=>testStorage[k]=String(v),getItem:k=>testStorage[k]??null}});")
                page.add_script_tag(content=js('xiumi-model.js'))
                # Offline dependency injection: no request/navigation to Xiumi.
                # Function bodies remain unchanged; only module exports and test location are bound.
                binding = 'const crypto={subtle:{digest:async (_,bytes)=>new Uint8Array(await window.digestForOfflineTest(Array.from(bytes))).buffer}};const location={hostname:"xiumi.us",hash:"#/paper/for/123/cube/0",href:"https://xiumi.us/studio/v5#/paper/for/123/cube/0"};'
                sources='\n'.join(js(f) for f in ('page-runtime.js','payload.js','capture-page.js'))
                page.add_script_tag(content='(()=>{'+binding+sources+'\nwindow.applyBridgeInPage=applyBridgeInPage;window.normalizePayload=normalizePayload;window.capturePage=capturePage;})()')
                page.evaluate('(opts)=>installXiumiModel(opts)',opts or {})
            setup()
            normalized=page.evaluate('(p)=>normalizePayload(p)',packet);assert normalized['schema']=='xiumi-bridge/v3';checks.append('actual normalizePayload accepts generated packet')
            page.evaluate('localStorage.setItem("ngStorage-localShowData","do-not-change")')
            result=page.evaluate('(p)=>applyBridgeInPage(p,"insert")',packet);assert result['ok'],result
            model=page.evaluate('JSON.parse(JSON.stringify(window.xiumiModel))')
            assert len(model['model'])==4;checks.append('actual importer creates four separate native text models')
            assert sum(x.startswith('upload:') for x in model['calls'])==1;checks.append('embedded image uploads once before insertion')
            assert 'data:image' not in json.dumps(model['model']);checks.append('no base64 remains in native article models')
            assert page.evaluate('localStorage.getItem("ngStorage-localShowData")')=='do-not-change';checks.append('existing draft cache is untouched')
            page.screenshot(path=str(out/'synthetic-import.png'),full_page=True)
            opts={'html':[x['txt1']['text'] for x in model['model']],'pageStyle':model['page']['comp']['_comp']['style']}
            receipt=result['receipt'];setup(opts)
            verified=page.evaluate('({p,r})=>applyBridgeInPage(p,"verify",r)',{'p':packet,'r':receipt});assert verified['ok'],verified;checks.append('serialized/reloaded synthetic draft passes receipt verification')
            source=page.evaluate('capturePage()');assert source and source.get('html');assert source['source']['pageFormat']['styles']['font-size']=='14px'
            raw={'schema':'opslion-template/v2','title':'由原 capturePage 捕获的合成母版','sourceType':'xiumi',**source}
            write_json(out/'actual-capture-fixture.opslion-template.json',raw)
            a=analyze(out/'actual-capture-fixture.opslion-template.json',out/'capture-analysis');assert len(a['moduleCandidates'])==4;checks.append('actual capturePage output is parsed without pre-labeling or app preprocessing')
            setup({'failUpload':True});failed=page.evaluate('(p)=>applyBridgeInPage(p,"insert")',packet)
            assert not failed['ok'] and page.evaluate('xiumiModel.model.length')==0;checks.append('failed upload leaves article empty')
            setup({'failInsert':True});failed=page.evaluate('(p)=>applyBridgeInPage(p,"insert")',packet)
            assert not failed['ok'] and page.evaluate('xiumiModel.model.length')==0;checks.append('failed insertion rolls back native modules')
            setup({'html':['<p>已有正文</p>']});failed=page.evaluate('(p)=>applyBridgeInPage(p,"insert")',packet)
            assert not failed['ok'];checks.append('nonempty target is rejected; no original article is overwritten')
            b.close()
    result={'passed':len(checks),'checks':checks,'environment':'real Chromium about:blank + synthetic model fixture; location, SHA-256 and storage are offline test dependencies; all requests blocked','realAccount':False,'serverSaveTested':False}
    write_json(out/'browser-contract-results.json',result);return result
if __name__=='__main__':print(json.dumps(run(sys.argv[1] if len(sys.argv)>1 else 'browser-test-results'),ensure_ascii=False,indent=2))
