"""Deterministic editorial checks and fixtures; no model or live-source claims."""
from __future__ import annotations

import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from validate_markdown import validate_text

TEMPLATE = json.loads((ROOT / 'references/template/hello-week.template.json').read_text(encoding='utf-8'))
HEAD = '<!-- opslion:hello-week/v1 -->\n# Hello Week丨测试\n<!-- layout: classic -->\n\n'
SCOPE = ':::section 本周回顾\n:::\n\n:::category 学术信息\n:::\n\n'
LINK = '- 详情请见：[活动原文](https://example.com/event)'
BODY = '- 时间：9月10日14:00\n- 地点：学院报告厅\n- 内容：本次交流讨论实验复现与结果分析。\n' + LINK


def doc(body: str, kind: str = 'news') -> str:
    return HEAD + (SCOPE if kind == 'news' else '') + f':::{kind} 测试事件\n{body}\n:::\n'


def check(text: str, **kwargs) -> dict:
    return validate_text(text, TEMPLATE, allow_demo=kwargs.pop('allow_demo', True), editorial=True, **kwargs)


def codes(result: dict, severity: str) -> set[str]:
    return {item['code'] for item in result[severity]}


class EditorialTests(unittest.TestCase):
    def test_standard_four_fields(self):
        result = check(doc(BODY))
        self.assertTrue(result['ok'], result)
        self.assertFalse(result['warnings'], result)

    def test_award_without_time_and_location(self):
        result = check(doc('- 内容：学院教师获年度教学奖。\n' + LINK))
        self.assertTrue(result['ok'], result)
        self.assertFalse(result['warnings'], result)

    def test_lecture_with_speaker_and_host(self):
        body = BODY.replace('- 内容：', '- 报告人：林远\n- 主持人：陈明\n- 内容：')
        result = check(doc(body))
        self.assertTrue(result['ok'], result)
        self.assertFalse(result['warnings'], result)

    def test_independent_application_dates(self):
        body = ('- 报名时间：6月1日至6月15日17:00\n- 活动时间：7月4日至7月7日\n'
                '- 材料提交：6月15日17:00前\n- 活动地点：燕园校区\n'
                '- 内容：夏令营面向相关专业本科生，申请时需提交指定材料。\n' + LINK)
        result = check(doc(body))
        self.assertTrue(result['ok'], result)
        self.assertFalse(result['warnings'], result)

    def test_metadata_labels_rejected(self):
        for label in ['来源公众号', '发布时间', '推文发布日期', '来源', '采集时间', '发文日期', 'source_account', 'published_at']:
            with self.subTest(label=label):
                result = check(doc(BODY.replace(LINK, f'- {label}：测试值\n{LINK}')))
                self.assertIn('editorial_metadata', codes(result, 'errors'))

    def test_metadata_plain_bold_and_continued(self):
        for line in ['来源公众号：北京大学', '- **来源公众号**：北京大学', '  发布时间：2026-09-13', '- **发布时间：**2026-09-13']:
            with self.subTest(line=line):
                result = check(doc(BODY.replace(LINK, line + '\n' + LINK)))
                self.assertIn('editorial_metadata', codes(result, 'errors'))

    def test_notice_has_same_metadata_guard(self):
        result = check(doc('- 发布时间：9月10日\n- 内容：活动调整至9月25日。\n' + LINK, kind='notice'))
        self.assertIn('editorial_metadata', codes(result, 'errors'))

    def test_details_account_prefix_rejected(self):
        result = check(doc(BODY.replace('详情请见：', '详情请见：北京大学｜')))
        self.assertIn('editorial_details_metadata', codes(result, 'errors'))

    def test_details_publication_suffix_rejected(self):
        result = check(doc(BODY + '（2026-09-13）'))
        self.assertIn('editorial_details_metadata', codes(result, 'errors'))

    def test_dates_and_organization_in_real_link_title_allowed(self):
        result = check(doc(BODY.replace('[活动原文]', '[北京大学9月10日活动通知]')))
        self.assertTrue(result['ok'], result)
        self.assertFalse(result['warnings'], result)

    def test_multiple_source_links_share_one_field(self):
        result = check(doc(BODY + '；[补充通知](https://example.com/update?x=1&y=2)'))
        self.assertTrue(result['ok'], result)
        self.assertFalse(result['warnings'], result)

    def test_source_link_continuations(self):
        body = BODY + '\n  [补充通知](https://example.com/update)'
        result = check(doc(body))
        self.assertTrue(result['ok'], result)
        self.assertFalse(result['warnings'], result)

    def test_source_link_on_continuation_after_empty_label(self):
        body = BODY.replace(LINK, '- 详情请见：\n  [活动原文](https://example.com/event)')
        result = check(doc(body))
        self.assertTrue(result['ok'], result)
        self.assertFalse(result['warnings'], result)

    def test_continued_source_metadata_rejected(self):
        body = BODY + '\n  北京大学｜[补充通知](https://example.com/update)'
        result = check(doc(body))
        self.assertIn('editorial_details_metadata', codes(result, 'errors'))

    def test_duplicate_details_warns(self):
        result = check(doc(BODY + '\n- 详情请见：[补充通知](https://example.com/update)'))
        self.assertTrue(result['ok'], result)
        self.assertIn('editorial_duplicate_details', codes(result, 'warnings'))

    def test_no_details_field_rejected_in_editorial_only(self):
        text = doc(BODY.replace('- 详情请见：', '- 参考链接：'))
        self.assertTrue(validate_text(text, TEMPLATE, allow_demo=True)['ok'])
        self.assertIn('editorial_details_missing', codes(check(text), 'errors'))

    def test_details_needs_a_text_link(self):
        text = doc(BODY.replace(LINK, '- 详情请见：https://example.com/event'))
        self.assertIn('editorial_details_link', codes(check(text), 'errors'))

    def test_fragmented_fields_warn(self):
        for label in ['获奖情况', '教学与科研', '同院系入选', '信科参与', '科普讲座', '电脑义诊', '服务范围', '原文安排']:
            with self.subTest(label=label):
                result = check(doc(BODY.replace('- 内容：', f'- {label}：相关事实\n- 内容：')))
                self.assertTrue(result['ok'], result)
                self.assertIn('editorial_fragmented_field', codes(result, 'warnings'))

    def test_arbitrary_necessary_field_is_not_banned(self):
        result = check(doc(BODY.replace('- 内容：', '- 签到要求：携带学生证\n- 内容：')))
        self.assertTrue(result['ok'], result)
        self.assertFalse(result['warnings'], result)

    def test_more_than_six_is_a_warning_only(self):
        body = BODY.replace('- 内容：', '- 报告人：林远\n- 主持人：陈明\n- 报名截止：9月9日\n- 内容：')
        result = check(doc(body))
        self.assertTrue(result['ok'], result)
        self.assertIn('editorial_field_count', codes(result, 'warnings'))

    def test_content_alias_warns(self):
        result = check(doc(BODY.replace('- 内容：', '- 活动内容：')))
        self.assertIn('editorial_content_missing', codes(result, 'warnings'))
        self.assertIn('editorial_fragmented_field', codes(result, 'warnings'))

    def test_duplicate_content_warns(self):
        result = check(doc(BODY.replace(LINK, '- 内容：另一段活动信息。\n' + LINK)))
        self.assertIn('editorial_duplicate_content', codes(result, 'warnings'))

    def test_article_as_subject_warns(self):
        result = check(doc(BODY.replace('本次交流讨论实验复现与结果分析。', '推文介绍了本次交流的主要安排。')))
        self.assertIn('editorial_article_subject', codes(result, 'warnings'))

    def test_qr_entry_reference_is_allowed(self):
        result = check(doc(BODY.replace('结果分析。', '结果分析，报名入口见原推文。')))
        self.assertTrue(result['ok'], result)
        self.assertFalse(result['warnings'], result)

    def test_article_words_inside_link_title_are_not_prose(self):
        result = check(doc(BODY.replace('[活动原文]', '[文章介绍与文案培训]')))
        self.assertFalse(result['warnings'], result)

    def test_multisession_fixture(self):
        result = check((ROOT / 'examples/multi-session.md').read_text(encoding='utf-8'))
        self.assertTrue(result['ok'], result)
        self.assertFalse(result['warnings'], result)

    def test_notice_multiple_stages(self):
        body = ('- 公告期：9月9日至15日\n- 挂牌期：9月16日至30日\n'
                '- 挂牌公示期：10月1日至12月31日\n- 内容：请检查并维护在用车辆。\n' + LINK)
        result = check(doc(body, kind='notice'))
        self.assertTrue(result['ok'], result)
        self.assertFalse(result['warnings'], result)

    def test_all_editorial_synthetic_results(self):
        for name in ['worked-result.md', 'multi-session.md', 'notice-only.md', 'award.md']:
            with self.subTest(name=name):
                result = check((ROOT / 'examples' / name).read_text(encoding='utf-8'))
                self.assertTrue(result['ok'], result)
                self.assertFalse(result['warnings'], result)

    def test_original_input_retains_internal_metadata(self):
        text = (ROOT / 'examples/worked-input/all-articles.md').read_text(encoding='utf-8')
        self.assertIn('来源公众号：', text)
        self.assertIn('发布时间：', text)
        result = (ROOT / 'examples/worked-result.md').read_text(encoding='utf-8')
        self.assertNotIn('来源公众号：', result)
        self.assertNotIn('发布时间：', result)

    def test_user_original_is_negative_editorial_fixture(self):
        text = (ROOT / 'examples/user-revision/original.md').read_text(encoding='utf-8')
        format_result = validate_text(text, TEMPLATE)
        self.assertTrue(format_result['ok'], format_result)
        result = check(text, allow_demo=False)
        self.assertFalse(result['ok'], result)
        self.assertEqual(sum(item['code'] == 'editorial_metadata' for item in result['errors']), 12)
        self.assertIn('editorial_fragmented_field', codes(result, 'warnings'))

    def test_user_revision_has_all_six_source_urls(self):
        directory = ROOT / 'examples/user-revision'
        text = (directory / 'revised.md').read_text(encoding='utf-8')
        urls = set(json.loads((directory / 'source-urls.json').read_text(encoding='utf-8')))
        self.assertEqual(len(urls), 6)
        self.assertEqual(set(re.findall(r'https://mp\.weixin\.qq\.com/s/[^)\s]+', text)), urls)
        result = check(text, allow_demo=False, source_urls=urls)
        self.assertTrue(result['ok'], result)
        self.assertFalse(result['warnings'], result)
        self.assertEqual((result['news'], result['notices']), (5, 1))

    def test_user_revision_does_not_relabel_publication_as_award_date(self):
        text = (ROOT / 'examples/user-revision/revised.md').read_text(encoding='utf-8')
        card = text.split(':::news 计算机学院罗国杰', 1)[1].split('\n:::', 1)[0]
        self.assertNotIn('- 时间：', card)
        self.assertNotIn('9月10日', card)
        self.assertIn('- 内容：', card)

    def test_user_visit_retains_scheduled_status(self):
        text = (ROOT / 'examples/user-revision/revised.md').read_text(encoding='utf-8')
        card = text.split(':::news “铭记·传承·奋进”', 1)[1].split('\n:::', 1)[0]
        self.assertIn('计划参访', card)
        self.assertNotIn('圆满', card)
        self.assertNotIn('- 原文安排：', card)

    def test_cli_editorial_option_is_read_only(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'article.md'
            path.write_text(doc(BODY + '\n- 来源公众号：大信科'), encoding='utf-8')
            before = path.read_bytes()
            proc = subprocess.run([sys.executable, str(ROOT / 'scripts/validate_markdown.py'),
                                   str(path), '--editorial', '--allow-demo', '--json'],
                                  capture_output=True, text=True)
            self.assertEqual(proc.returncode, 1, proc.stderr)
            self.assertIn('editorial_metadata', codes(json.loads(proc.stdout), 'errors'))
            self.assertEqual(path.read_bytes(), before)

    def test_obsolete_display_directives_removed(self):
        text = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
        for obsolete in ['- 来源公众号：来源中的真实公众号名', '- 发布时间：来源中实际存在的发布时间',
                         '保留题名、公众号与已有发布时间', '字段名可以按需增加；没有事实就省略整行']:
            self.assertNotIn(obsolete, text)
        self.assertIn('Skill 版本：3.1.0', text)
        self.assertIn('--editorial', text)


if __name__ == '__main__':
    unittest.main()
