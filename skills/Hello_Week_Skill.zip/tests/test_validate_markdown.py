"""Format and fixture checks; no real article extraction or model evaluation."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from validate_markdown import validate_text

TEMPLATE = json.loads((ROOT / 'references/template/hello-week.template.json').read_text(encoding='utf-8'))
HEAD = '<!-- opslion:hello-week/v1 -->\n# Hello Week丨测试\n<!-- layout: classic -->\n\n'
SCOPE = ':::section 下周及后续\n:::\n\n:::category 学术信息\n:::\n\n'
LINK = '- 详情请见：[原文标题](https://example.com/articles/1)'
NEWS = f':::news 测试活动\n- 时间：9月18日19:00\n{LINK}\n:::\n'
VALID = HEAD + SCOPE + NEWS


def check(text: str, **kwargs) -> dict:
    return validate_text(text, TEMPLATE, allow_demo=kwargs.pop('allow_demo', True), **kwargs)


class MarkdownContractTests(unittest.TestCase):
    def assert_error(self, text: str, code: str, **kwargs):
        result = check(text, **kwargs)
        self.assertIn(code, [item['code'] for item in result['errors']], result)

    def test_minimal_news(self):
        result = check(VALID)
        self.assertTrue(result['ok'], result)
        self.assertEqual((result['modules'], result['news'], result['notices']), (3, 1, 0))

    def test_all_three_layouts(self):
        for layout in TEMPLATE['layouts']:
            with self.subTest(layout=layout):
                self.assertTrue(check(VALID.replace('layout: classic', f'layout: {layout}'))['ok'])

    def test_header_blank_lines(self):
        text = VALID.replace(' -->\n# ', ' -->\n\n# ').replace('测试\n<!-- layout', '测试\n\n<!-- layout')
        self.assertTrue(check(text)['ok'])

    def test_header_utf8_bom_crlf(self):
        self.assertTrue(check('\ufeff' + VALID.replace('\n', '\r\n'))['ok'])

    def test_wrong_marker(self):
        self.assert_error(VALID.replace('opslion:hello-week/v1', 'opslion:hello-week/v2'), 'marker')

    def test_header_title_missing(self):
        self.assert_error(VALID.replace('# Hello Week丨测试', '# '), 'title')

    def test_bad_layout(self):
        self.assert_error(VALID.replace('layout: classic', 'layout: wide'), 'layout')

    def test_header_order(self):
        self.assert_error(VALID.replace('# Hello Week丨测试\n<!-- layout: classic -->', '<!-- layout: classic -->\n# Hello Week丨测试'), 'title')

    def test_body_outside_module(self):
        self.assert_error(HEAD + '额外正文\n' + SCOPE + NEWS, 'outside_module')

    def test_unknown_module(self):
        self.assert_error(HEAD + ':::summary\n正文\n:::\n', 'unknown_module')

    def test_unclosed_module(self):
        self.assert_error(VALID.rstrip().removesuffix(':::'), 'unclosed_module')

    def test_orphan_close(self):
        self.assert_error(VALID + '\n:::\n', 'orphan_close')

    def test_nested_module(self):
        self.assert_error(HEAD + ':::notice 提醒\n:::news 嵌套\n内容\n:::\n', 'nested_module')

    def test_indented_module(self):
        self.assert_error(VALID.replace(':::news', '  :::news'), 'module_marker')

    def test_required_titles(self):
        for kind in ['callout', 'section', 'category', 'news', 'notice', 'credits']:
            with self.subTest(kind=kind):
                self.assert_error(HEAD + SCOPE + f':::{kind}\n{LINK}\n:::\n', 'missing_title')

    def test_title_not_allowed(self):
        self.assert_error(HEAD + ':::banner 标题\n:::\n', 'unexpected_title')

    def test_fixed_modules_empty_body(self):
        for kind in ['banner', 'divider', 'footer', 'code-outro', 'code-intro']:
            with self.subTest(kind=kind):
                self.assert_error(HEAD + f':::{kind}\n额外正文\n:::\n', 'fixed_body')

    def test_required_body(self):
        self.assert_error(HEAD + ':::notice 提醒\n:::\n', 'missing_body')

    def test_intro_parameter(self):
        self.assertTrue(check(HEAD + ':::code-intro semester-end\n:::\n')['ok'])
        self.assert_error(HEAD + ':::code-intro opening\n:::\n', 'intro_mode')

    def test_spacer_parameter(self):
        for size in [8, 12, 16, 24, 28, 32, 40, 48]:
            self.assertTrue(check(HEAD + f':::spacer {size}\n:::\n')['ok'])
        self.assert_error(HEAD + ':::spacer 20\n:::\n', 'space_size')

    def test_category_requires_section(self):
        self.assert_error(HEAD + ':::category 学术信息\n:::\n' + NEWS, 'category_context')

    def test_news_requires_category(self):
        self.assert_error(HEAD + ':::section 本周回顾\n:::\n' + NEWS, 'news_context')

    def test_new_section_clears_category(self):
        self.assert_error(VALID + '\n:::section 另一分区\n:::\n' + NEWS, 'news_context')

    def test_all_seven_category_breakers(self):
        cases = {
            'divider': ':::divider\n:::\n',
            'transition': ':::transition\n接下来\n:::\n',
            'notice': ':::notice 提醒\n正文\n:::\n',
            'contact': ':::contact\n正文\n:::\n',
            'closing': ':::closing\n正文\n:::\n',
            'credits': ':::credits 栏目组\n文案丨已确认作者\n:::\n',
            'code-outro': ':::code-outro\n:::\n',
        }
        for kind, block in cases.items():
            with self.subTest(kind=kind):
                self.assert_error(VALID + block + NEWS, 'news_context')
                fixed = VALID + block + ':::category 学术信息\n:::\n' + NEWS
                self.assertTrue(check(fixed)['ok'], check(fixed))

    def test_spacer_does_not_clear_category(self):
        self.assertTrue(check(VALID + ':::spacer 24\n:::\n' + NEWS)['ok'])

    def test_empty_category(self):
        self.assert_error(VALID + ':::category 活动信息\n:::\n', 'empty_category')

    def test_empty_section(self):
        self.assert_error(HEAD + ':::section 本周回顾\n:::\n:::footer\n:::\n', 'empty_section')

    def test_news_missing_source(self):
        self.assert_error(VALID.replace(LINK, '- 内容：活动内容'), 'news_source')

    def test_raw_url_not_a_source(self):
        self.assert_error(VALID.replace(LINK, '- 详情请见：https://example.com/a'), 'news_source')

    def test_image_link_not_a_source(self):
        self.assert_error(VALID.replace(LINK, '![原文海报](https://example.com/poster.png)'), 'news_source')

    def test_code_link_not_a_source(self):
        self.assert_error(VALID.replace(LINK, '`[原文](https://example.com/a)`'), 'news_source')
        self.assert_error(VALID.replace(LINK, '```text\n[原文](https://example.com/a)\n```'), 'news_source')

    def test_non_http_source(self):
        for target in ['javascript:alert(1)', 'mailto:a@example.com', 'file:///a', 'assets/a.html', 'https://']:
            with self.subTest(target=target):
                self.assert_error(VALID.replace('https://example.com/articles/1', target), 'link_target')

    def test_url_query_ampersand(self):
        self.assertTrue(check(VALID.replace('articles/1', 'a?x=1&y=2'))['ok'])
        self.assert_error(VALID.replace('articles/1', 'a?x=1&amp;y=2'), 'escaped_query')

    def test_balanced_url_parentheses(self):
        text = VALID.replace('articles/1', 'path/(one(two))?x=(3)&y=4')
        self.assertTrue(check(text)['ok'], check(text))

    def test_url_whitespace_and_link_title(self):
        self.assert_error(VALID.replace('articles/1', 'a b'), 'link_whitespace')
        self.assert_error(VALID.replace('articles/1', 'a "title"'), 'link_whitespace')
        self.assertTrue(check(VALID.replace('articles/1', 'a%20b'))['ok'])

    def test_escaped_link_label(self):
        self.assertTrue(check(VALID.replace('原文标题', r'算法 \[进阶\] 与 \(练习\)'))['ok'])

    def test_nested_links(self):
        self.assert_error(VALID.replace(LINK, '- 来源：[外层[内层](https://example.com/b)](https://example.com/a)'), 'nested_link')

    def test_unclosed_link(self):
        self.assert_error(VALID.replace('articles/1)', 'articles/1'), 'unclosed_link')

    def test_known_source_url_list(self):
        self.assertTrue(check(VALID, source_urls={'https://example.com/articles/1'})['ok'])
        self.assert_error(VALID, 'source_membership', source_urls={'https://example.com/form'})
        text = VALID.replace('articles/1', 'a%20b')
        self.assertTrue(check(text, source_urls={'https://example.com/a b'})['ok'])

    def test_notice_does_not_need_source(self):
        self.assertTrue(check(HEAD + ':::notice 编辑已确认提醒\n请按既定安排准备材料。\n:::\n')['ok'])

    def test_dangling_notice_transition(self):
        self.assert_error(VALID + ':::transition\n记得查收重要提示哦\n:::\n', 'dangling_notice_transition')

    def test_no_empty_notice_required(self):
        self.assertEqual(check(VALID)['notices'], 0)

    def test_no_items_with_fixed_modules(self):
        result = check(HEAD + ':::banner\n:::\n:::footer\n:::\n')
        self.assertTrue(result['ok'], result)
        self.assertIn('no_dynamic_items', [d['code'] for d in result['warnings']])

    def test_multisession_two_spaces(self):
        body = '- 场次一：\n  时间：9月18日\n  地点：会场一\n- 场次二：\n  时间：9月19日\n  地点：会场二'
        self.assertTrue(check(VALID.replace('- 时间：9月18日19:00', body))['ok'])

    def test_wrong_continuation_indent(self):
        for indent in [' ', '    ']:
            self.assert_error(VALID.replace('- 时间：9月18日19:00', '- 场次：\n' + indent + '时间：9月18日'), 'continuation_indent')

    def test_continuation_without_list(self):
        self.assert_error(VALID.replace('- 时间：9月18日19:00', '  时间：9月18日'), 'continuation_indent')

    def test_image_or_code_in_continuation(self):
        for content in ['![图片](https://example.com/a.png)', '```cpp', '- 新列表']:
            with self.subTest(content=content):
                self.assert_error(VALID.replace('- 时间：9月18日19:00', '- 场次：\n  ' + content), 'continuation_content')

    def test_inline_image(self):
        self.assert_error(VALID.replace('- 时间：9月18日19:00', '说明 ![图片](https://example.com/a.png)'), 'inline_image')

    def test_known_asset_aliases(self):
        for alias in TEMPLATE['assets']:
            self.assertTrue(check(HEAD + f':::image\n![固定素材](asset:{alias})\n:::\n')['ok'])

    def test_unknown_asset_and_local_image(self):
        self.assert_error(HEAD + ':::image\n![图](asset:other)\n:::\n', 'link_target')
        self.assert_error(HEAD + ':::image\n![图](assets/one.png)\n:::\n', 'link_target')

    def test_image_module_needs_image(self):
        self.assert_error(HEAD + ':::image\n只有说明\n:::\n', 'missing_image')

    def test_internal_heading_four_only(self):
        self.assertTrue(check(VALID.replace('- 时间：9月18日19:00', '#### 报名条件\n- 条件：按原文'))['ok'])
        self.assert_error(VALID.replace('- 时间：9月18日19:00', '## 错误小标题'), 'heading')

    def test_table_and_html(self):
        self.assert_error(VALID.replace('- 时间：9月18日19:00', '| A | B |\n| --- | --- |\n| a | b |'), 'table')
        self.assert_error(VALID.replace('- 时间：9月18日19:00', '<p>正文</p>'), 'html')
        self.assertTrue(check(VALID.replace('- 时间：9月18日19:00', '技术类型 `<T>`'))['ok'])

    def test_task_list_not_supported(self):
        self.assert_error(VALID.replace('- 时间：9月18日19:00', '- [ ] 事项'), 'task_list')

    def test_fenced_code_languages(self):
        for language in ['', 'cpp', 'text']:
            self.assertTrue(check(HEAD + f':::closing\n```{language}\nline();\n```\n:::\n')['ok'])
        self.assert_error(HEAD + ':::closing\n```python\nprint(1)\n```\n:::\n', 'fence_language')

    def test_independent_code_unwrapped(self):
        self.assertTrue(check(HEAD + ':::code\nconst x = 1;\n:::\n')['ok'])
        self.assert_error(HEAD + ':::code\n```cpp\nconst x=1;\n```\n:::\n', 'code_fence')

    def test_production_demo_url_guard(self):
        self.assert_error(VALID, 'demo_url', allow_demo=False)

    def test_production_placeholder_guard(self):
        text = HEAD + ':::contact\n联系人：示例联系人\n:::\n'
        self.assert_error(text, 'placeholder', allow_demo=False)

    def test_module_limit(self):
        self.assert_error(HEAD + ':::banner\n:::\n' * 501, 'module_limit')

    def test_character_limit(self):
        self.assert_error(HEAD + ':::code\n' + 'x' * 1_000_000 + '\n:::\n', 'character_limit')

    def test_large_body_is_not_truncated(self):
        result = check(VALID.replace('- 时间：9月18日19:00', '- 内容：' + '真实材料内容。' * 200))
        self.assertTrue(result['ok'], result)

    def test_template_originals(self):
        t = ROOT / 'references/template'
        files = [t / 'starter.md', t / 'all-modules.md', *sorted((t / 'examples').glob('*.md'))]
        self.assertEqual(len(files), 7)
        for path in files:
            with self.subTest(path=path.name):
                result = check(path.read_text(encoding='utf-8'))
                self.assertTrue(result['ok'], result)
        all_modules = (t / 'all-modules.md').read_text(encoding='utf-8')
        self.assertEqual(len(TEMPLATE['modules']), 18)
        for module in TEMPLATE['modules']:
            self.assertIn(':::' + module, all_modules)

    def test_preserved_template_hashes(self):
        lock = json.loads((ROOT.parent / 'template-lock.json').read_text(encoding='utf-8'))
        for name, expected in lock['files'].items():
            with self.subTest(name=name):
                actual = hashlib.sha256((ROOT / 'references/template' / name).read_bytes()).hexdigest()
                self.assertEqual(actual, expected)

    def test_worked_fixture(self):
        result = check((ROOT / 'examples/worked-result.md').read_text(encoding='utf-8'),
                       source_urls=set(json.loads((ROOT / 'examples/source-urls.json').read_text(encoding='utf-8'))))
        self.assertTrue(result['ok'], result)
        self.assertEqual((result['news'], result['notices']), (5, 0))
        text = (ROOT / 'examples/worked-result.md').read_text(encoding='utf-8')
        self.assertEqual(text.count(':::news 系统研究讨论会'), 1)
        for omitted in [':::notice', '查收重要提示', '校园棋赛', '青年论坛', '图算法交流', '行业闭门']:
            self.assertNotIn(omitted, text)
        for preserved in ['a02?from=rss&issue=1', 'articles/a03', '10月10日', '9月19日17:00']:
            self.assertIn(preserved, text)

    def test_other_fixtures(self):
        for filename in ['multi-session.md', 'notice-only.md', 'no-items.md']:
            with self.subTest(filename=filename):
                result = check((ROOT / 'examples' / filename).read_text(encoding='utf-8'))
                self.assertTrue(result['ok'], result)

    def test_error_line_number(self):
        result = check(VALID.replace(':::news 测试活动', ':::news'))
        line = next(item['line'] for item in result['errors'] if item['code'] == 'missing_title')
        self.assertEqual(line, VALID.splitlines().index(':::news 测试活动') + 1)

    def test_cli_is_read_only_and_reports_json(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'article.md'
            path.write_bytes(VALID.encode('utf-8'))
            before = path.read_bytes()
            proc = subprocess.run([sys.executable, str(ROOT / 'scripts/validate_markdown.py'), str(path), '--allow-demo', '--json'], capture_output=True, text=True)
            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertTrue(json.loads(proc.stdout)['ok'])
            self.assertEqual(path.read_bytes(), before)

    def test_cli_rejects_invalid_utf8(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'bad.md'
            path.write_bytes(b'\xff\xfe\x00')
            proc = subprocess.run([sys.executable, str(ROOT / 'scripts/validate_markdown.py'), str(path)], capture_output=True)
            self.assertEqual(proc.returncode, 2)


if __name__ == '__main__':
    unittest.main()
