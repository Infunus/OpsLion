<!-- opslion:hello-week/v1 -->
# Hello Week丨获奖合成演示（非当期发布稿）
<!-- layout: classic -->

:::section 本周回顾
:::

:::category 学术信息
:::

:::news 学院教师获年度教学奖
- 时间：9月10日
- 内容：学院教师林远获年度教学奖。他承担计算机系统课程教学，并指导学生开展实验复现与科研训练。
- 详情请见：[学院教师获年度教学奖](https://example.com/teaching-award)
:::
