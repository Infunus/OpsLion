<!-- opslion:hello-week/v1 -->
# Hello Week丨合成采编演示（非当期发布稿）
<!-- layout: classic -->

:::banner
:::

:::code-intro
:::

:::divider
:::

:::section 上周回顾
:::

:::category 学术信息
:::

:::news 本科生科研经验交流会
- 时间：9月10日
- 地点：理科二号楼交流室
- 内容：来自不同研究方向的同学分享文献阅读、复现实验及与导师交流的方法，并回答低年级同学的提问。
- 详情请见：[本科生科研经验交流会举行](https://example.com/articles/a01)
:::

:::divider
:::

:::transition
看完了上周信息
再来看看下周及后续的重要信息吧
:::

:::section 下周及后续
:::

:::category 学术信息
:::

:::news 系统研究讨论会
- 时间：9月18日19:00
- 地点：学院报告厅
- 报告人：林远
- 报名截止：9月16日18:00
- 内容：讨论会面向信息科学技术学院本科生，围绕计算机系统实验中的指标选取、结果复现和误差分析开展讨论。报名时需在[报名表](https://example.com/forms/systems)中提交拟讨论的问题。
- 详情请见：[系统研究讨论会报名](https://example.com/articles/a02?from=rss&issue=1)；[系统研究讨论会补充通知](https://example.com/articles/a03)
:::

:::news 数据系统实验交流
- 时间：9月17日15:00
- 地点：研究生讨论室
- 内容：交流面向计算机学院师生，围绕数据处理流程的实验复现展开。
- 详情请见：[两场学术交流预告](https://example.com/articles/a08)
:::

:::news 算法训练营申请
- 活动时间：10月10日
- 申请截止：9月19日17:00
- 内容：训练营面向信科本科生，围绕算法题目分析与程序验证开展练习。申请人需提交一份个人学习计划。
- 详情请见：[算法训练营申请通知](https://example.com/articles/a05)
:::

:::category 活动信息
:::

:::news 校园阅读交换活动
- 时间：9月20日14:00
- 地点：学生活动中心
- 内容：活动面向北京大学全体在校学生，参加者可携带一册保存完好的书，与其他同学交换并分享阅读体会。
- 详情请见：[校园阅读交换活动](https://example.com/articles/a07)
:::

:::divider
:::

:::code-outro
:::

:::footer
:::
