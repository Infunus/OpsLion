<!-- opslion:hello-week/v1 -->
# Hello Week丨多场次合成演示（非当期发布稿）
<!-- layout: inset -->

:::banner
:::

:::section 下周及后续
:::

:::category 活动信息
:::

:::news 学生交流日
- 主题交流：
  时间：9月19日14:00—15:00
  地点：交流室一
- 作品展示：
  时间：9月19日15:30—17:00
  地点：交流室二
- 面向对象：信科学生
- 详情请见：大信科｜[学生交流日安排](https://example.com/student-day)
:::

:::footer
:::
