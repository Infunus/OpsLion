<!-- opslion:hello-week/v1 -->
# Hello Week丨改期提醒合成演示（非当期发布稿）
<!-- layout: spaced -->

:::banner
:::

:::section 重要提示
:::

:::notice 系统研究讨论会改期
- 最新安排：原定9月18日的系统研究讨论会调整至9月25日。
- 详情请见：北京大学计算机学院｜[系统研究讨论会改期通知](https://example.com/date-change)
:::

:::footer
:::
