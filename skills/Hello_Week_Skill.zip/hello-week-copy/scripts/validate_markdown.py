#!/usr/bin/env python3
"""Read-only checks for the Hello Week v1 authoring contract.

This is a conservative author-side linter, not OpsLion's browser compiler.
It does not assess factual correctness, deduplication, or Bridge payload size.
Requires Python 3.10+ and the standard library only.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import json
from pathlib import Path
import re
import sys
from urllib.parse import urlsplit

DEFAULT_TEMPLATE = Path(__file__).resolve().parents[1] / "references/template/hello-week.template.json"
BREAK_CATEGORY = {"divider", "transition", "notice", "contact", "closing", "credits", "code-outro"}
SPACE_SIZES = {"8", "12", "16", "24", "28", "32", "40", "48"}
CONTENT_MODULES = {"news", "notice", "callout", "contact", "welcome", "closing", "image"}
DEMO_DOMAIN = re.compile(r"(?i)(?:^|[.@/:])(?:example\.(?:com|org|net)|[^/\s]+\.invalid)(?=$|[/:?\s])")
PLACEHOLDER = re.compile(r"这里填写|请替换为|示例联系人|示例作者|示例署名|示例排版人员|以原文为准的示例|待补充|\{\{[^}]+\}\}")
MODULE_START = re.compile(r"^:::([a-z][a-z0-9-]*)(?: (.*))?$")
LIST_ITEM = re.compile(r"^(?:- |\d+\. )")
HTML_TAG = re.compile(r"</?[A-Za-z][^>]*>|<!--")
TABLE_SEPARATOR = re.compile(r"^\s*\|?\s*:?-{3,}:?\s*\|(?:\s*:?-{3,}:?\s*\|?)+\s*$")


@dataclass(frozen=True)
class Diagnostic:
    line: int
    code: str
    message: str


@dataclass
class Block:
    kind: str
    title: str
    line: int
    body: list[tuple[int, str]]


@dataclass(frozen=True)
class Link:
    line: int
    label: str
    url: str
    image: bool
    start: int
    end: int


def _escaped(text: str, pos: int) -> bool:
    n = 0
    pos -= 1
    while pos >= 0 and text[pos] == "\\":
        n += 1
        pos -= 1
    return n % 2 == 1


def _unescape(text: str) -> str:
    return re.sub(r"\\([*\[\]()#>!_`\\])", r"\1", text)


def _target_valid(url: str, image: bool, template: dict) -> bool:
    if image and url.startswith("asset:"):
        return url[6:] in template["assets"]
    try:
        parsed = urlsplit(url)
        return parsed.scheme.lower() in {"http", "https"} and bool(parsed.netloc) and not re.search(r'[\s<>\x00-\x1f]', url)
    except ValueError:
        return False


def _take_link(text: str, start: int, line: int, errors: list[Diagnostic]) -> tuple[Link | None, int]:
    image = text.startswith("![", start)
    bracket = start + (1 if image else 0)
    depth = 1
    j = bracket + 1
    while j < len(text):
        if text[j] == "\\":
            j += 2
            continue
        if text[j] == "[":
            depth += 1
        elif text[j] == "]":
            depth -= 1
            if depth == 0:
                break
        j += 1
    if j >= len(text) or text[j:j + 2] != "](":
        return None, start + (2 if image else 1)
    label = text[bracket + 1:j]
    if re.search(r"(?<!\\)\[[^\n]*\]\(", label):
        errors.append(Diagnostic(line, "nested_link", "链接内不能再嵌套链接。"))
    begin = j + 2
    depth = 1
    k = begin
    while k < len(text):
        if text[k] == "\\":
            k += 2
            continue
        if text[k] == "(":
            depth += 1
        elif text[k] == ")":
            depth -= 1
            if depth == 0:
                raw = text[begin:k]
                if re.search(r"\s", raw):
                    errors.append(Diagnostic(line, "link_whitespace", "URL 空格须写为 %20，不能添加链接标题参数。"))
                return Link(line, _unescape(label), _unescape(raw), image, start, k + 1), k + 1
        k += 1
    errors.append(Diagnostic(line, "unclosed_link", "Markdown 链接的圆括号未闭合。"))
    return None, len(text)


def inline_links(text: str, line: int, template: dict, errors: list[Diagnostic], allow_demo: bool) -> list[Link]:
    """Parse explicit links, respecting escaping, inline code and URL parentheses."""
    links: list[Link] = []
    visible = list(text)
    i = 0
    while i < len(text):
        if text[i] == "\\":
            visible[i:i + 2] = " " * len(visible[i:i + 2])
            i += 2
            continue
        if text[i] == "`":
            j = i + 1
            while j < len(text) and (text[j] != "`" or _escaped(text, j)):
                j += 1
            if j == len(text):
                errors.append(Diagnostic(line, "inline_code", "行内代码的反引号未成对；显示反引号请转义。"))
                break
            visible[i:j + 1] = " " * (j + 1 - i)
            i = j + 1
            continue
        if text.startswith("![", i) or text[i] == "[":
            link, end = _take_link(text, i, line, errors)
            if link:
                links.append(link)
                visible[i:end] = " " * (end - i)
                if not _target_valid(link.url, link.image, template):
                    message = "图片必须使用 HTTP(S) 地址或模板支持的 asset: 别名。" if link.image else "来源/参与链接仅支持完整 HTTP(S) 地址。"
                    errors.append(Diagnostic(line, "link_target", message))
                if "&amp;" in link.url:
                    errors.append(Diagnostic(line, "escaped_query", "URL 查询参数须保留原始 &，不使用 &amp;。"))
                if not allow_demo and DEMO_DOMAIN.search(link.url):
                    errors.append(Diagnostic(line, "demo_url", "生产稿不能使用示例域名。"))
            i = end
            continue
        i += 1
    remainder = "".join(visible)
    if HTML_TAG.search(remainder):
        errors.append(Diagnostic(line, "html", "正文不生成 HTML 或 HTML 注释；展示技术字符可使用行内代码。"))
    if re.search(r"\[[^\]]+\]\[[^\]]*\]|^\s*\[[^\]]+\]:", remainder):
        errors.append(Diagnostic(line, "reference_link", "不支持引用式链接或脚注，请写显式内联链接。"))
    if not allow_demo and (PLACEHOLDER.search(text) or DEMO_DOMAIN.search(remainder)):
        errors.append(Diagnostic(line, "placeholder", "生产稿含占位文案或示例联系信息。"))
    return links


def _validate_body(block: Block, spec: dict, template: dict, errors: list[Diagnostic], allow_demo: bool) -> list[Link]:
    mode = spec["body"]
    nonempty = [(n, s) for n, s in block.body if s.strip()]
    if mode == "empty":
        if nonempty:
            errors.append(Diagnostic(nonempty[0][0], "fixed_body", f"{block.kind} 正文必须为空。"))
        return []
    if not nonempty:
        errors.append(Diagnostic(block.line, "missing_body", f"{block.kind} 正文不能为空。"))
        return []
    if mode == "code":
        if any(s.startswith("```") for _, s in block.body):
            errors.append(Diagnostic(block.line, "code_fence", "独立 code 模块直接放代码文本，无需再包代码围栏。"))
        return []
    links: list[Link] = []
    fence = False
    fence_line = block.line
    in_list = False
    image_count = 0
    for n, text in block.body:
        if text.startswith("```"):
            if mode == "lines":
                errors.append(Diagnostic(n, "line_body", f"{block.kind} 使用逐行文本，不放围栏代码块。"))
                continue
            if fence:
                if text != "```":
                    errors.append(Diagnostic(n, "fence_close", "代码块结束须独占一行三个反引号。"))
                fence = False
            else:
                if text not in {"```", "```cpp", "```text"}:
                    errors.append(Diagnostic(n, "fence_language", "代码块只接受 cpp、text 或不带语言。"))
                fence = True
                fence_line = n
            in_list = False
            continue
        if fence:
            continue
        if not text.strip():
            in_list = False
            continue
        if mode != "lines":
            if text.startswith("\t"):
                errors.append(Diagnostic(n, "tab_indent", "列表续行须用两个空格，不能用制表符。"))
            if text.startswith(" "):
                indent = len(text) - len(text.lstrip(" "))
                if indent != 2 or not in_list:
                    errors.append(Diagnostic(n, "continuation_indent", "只有列表项续行使用两个空格缩进。"))
                content = text.lstrip()
                if content.startswith(("![", "```", ":::")) or LIST_ITEM.match(content) or content.startswith("#### "):
                    errors.append(Diagnostic(n, "continuation_content", "续行仅放文本；图片、代码块、小标题和新模块须独立成行，不嵌套列表。"))
            elif LIST_ITEM.match(text):
                in_list = True
                if re.match(r"^- \[[ xX]\]", text):
                    errors.append(Diagnostic(n, "task_list", "不支持任务复选框。"))
            else:
                in_list = False
            if re.match(r"^#{1,6} ", text) and not text.startswith("#### "):
                errors.append(Diagnostic(n, "heading", "模块内小标题只用 ####，主标题写在模块起始行。"))
            if TABLE_SEPARATOR.match(text):
                errors.append(Diagnostic(n, "table", "不支持 Markdown 表格。"))
            if re.match(r"^(?:\* |\+ |\d+\) )", text):
                errors.append(Diagnostic(n, "list_marker", "信息行用 -，序号行用数字加点。"))
            if text in {"---", "***", "___"}:
                errors.append(Diagnostic(n, "rule", "段落分隔使用 divider 模块，不使用通用 Markdown 横线。"))
        row_links = inline_links(text, n, template, errors, allow_demo)
        for link in row_links:
            if link.image:
                image_count += 1
                if mode == "lines" or text[:link.start].strip() or text[link.end:].strip() or text.startswith(" "):
                    errors.append(Diagnostic(n, "inline_image", "Markdown 图片须独占一行，且不能放在列表续行或逐行文本模块中。"))
        links.extend(row_links)
    if fence:
        errors.append(Diagnostic(fence_line, "unclosed_fence", "代码块未闭合。"))
    if mode == "image" and image_count == 0:
        errors.append(Diagnostic(block.line, "missing_image", "image 模块至少需要一张独立 Markdown 图片。"))
    return links


def validate_text(text: str, template: dict, *, allow_demo: bool = False, source_urls: set[str] | None = None) -> dict:
    if template.get("id") != "hello-week/v1" or template.get("schema") != "opslion/weekly-template/v1":
        raise ValueError("此预检器只支持 hello-week/v1 的 opslion/weekly-template/v1 定义。")
    errors: list[Diagnostic] = []
    warnings: list[Diagnostic] = []
    utf16_size = len(text.encode("utf-16-le")) // 2
    if utf16_size > template["input"]["maxCharacters"]:
        errors.append(Diagnostic(1, "character_limit", "文案超过 100 万字符上限（预检保守按 UTF-16 单元计数）。"))
    lines = text.removeprefix("\ufeff").splitlines()
    header = [(i + 1, s) for i, s in enumerate(lines) if s.strip()][:3]
    if len(header) < 3:
        errors.append(Diagnostic(1, "header", "文件头需依次为版本标记、一级标题、layout 标记。"))
        return _result([], errors, warnings, utf16_size)
    if header[0][1] != template["input"]["marker"]:
        errors.append(Diagnostic(header[0][0], "marker", "首个非空行须为 <!-- opslion:hello-week/v1 -->。"))
    if not re.fullmatch(r"# \S.*", header[1][1]):
        errors.append(Diagnostic(header[1][0], "title", "第二个非空行须为一个非空一级标题。"))
    if not allow_demo and ("本期标题" in header[1][1] or PLACEHOLDER.search(header[1][1])):
        errors.append(Diagnostic(header[1][0], "placeholder", "请填入真实期次标题。"))
    layout_match = re.fullmatch(r"<!-- layout: ([a-z]+) -->", header[2][1])
    if not layout_match or layout_match[1] not in template["layouts"]:
        errors.append(Diagnostic(header[2][0], "layout", "layout 必须为 classic、spaced 或 inset，且按契约写注释。"))
    blocks: list[Block] = []
    active: Block | None = None
    in_fence = False
    for n in range(header[2][0] + 1, len(lines) + 1):
        text_line = lines[n - 1]
        if active and active.kind != "code" and text_line.startswith("```"):
            in_fence = not in_fence
            active.body.append((n, text_line))
            continue
        if active and in_fence:
            if text_line.startswith(":::"):
                errors.append(Diagnostic(n, "ambiguous_delimiter", "代码中不要生成独占的模块分隔行，以免与外层语法冲突。"))
            active.body.append((n, text_line))
            continue
        if text_line == ":::":
            if active is None:
                errors.append(Diagnostic(n, "orphan_close", "发现没有对应起始行的模块结束标记。"))
            else:
                blocks.append(active)
                active = None
            continue
        start = MODULE_START.fullmatch(text_line)
        if start:
            if active:
                errors.append(Diagnostic(n, "nested_module", "模块不能嵌套；前一模块须先用 ::: 结束。"))
                active.body.append((n, text_line))
            else:
                active = Block(start[1], start[2] or "", n, [])
            continue
        if text_line.lstrip().startswith(":::"):
            errors.append(Diagnostic(n, "module_marker", "模块标记须独占一行、使用合法 ID，且不缩进。"))
        if active:
            active.body.append((n, text_line))
        elif text_line.strip():
            errors.append(Diagnostic(n, "outside_module", "文件头之后的全部正文必须放在模块内。"))
    if active:
        errors.append(Diagnostic(active.line, "unclosed_module", f"{active.kind} 模块未闭合。"))
        blocks.append(active)
    if len(blocks) > template["input"]["maxModules"]:
        errors.append(Diagnostic(blocks[template["input"]["maxModules"]].line, "module_limit", "模块数超过 500。"))

    current_section: Block | None = None
    section_content = 0
    current_category: Block | None = None
    category_news = 0
    normal_source_urls = {u.replace(" ", "%20") for u in source_urls} if source_urls is not None else None
    for block in blocks:
        spec = template["modules"].get(block.kind)
        if spec is None:
            errors.append(Diagnostic(block.line, "unknown_module", f"未知模块 ID：{block.kind}。"))
            continue
        title_mode = spec["title"]
        if title_mode == "none" and block.title:
            errors.append(Diagnostic(block.line, "unexpected_title", f"{block.kind} 不接受标题/参数。"))
        if title_mode == "required" and not block.title.strip():
            errors.append(Diagnostic(block.line, "missing_title", f"{block.kind} 需要标题。"))
        if title_mode == "intro-mode" and block.title not in {"", "semester-end"}:
            errors.append(Diagnostic(block.line, "intro_mode", "code-intro 参数只允许空或 semester-end。"))
        if title_mode == "space-size" and block.title not in SPACE_SIZES:
            errors.append(Diagnostic(block.line, "space_size", "spacer 参数须为 8/12/16/24/28/32/40/48。"))
        if not allow_demo and PLACEHOLDER.search(block.title):
            errors.append(Diagnostic(block.line, "placeholder", "模块标题含占位文案。"))
        if HTML_TAG.search(block.title):
            errors.append(Diagnostic(block.line, "html", "模块标题不含 HTML。"))
        if block.kind in {"section", "category"} or block.kind in BREAK_CATEGORY:
            if current_category and category_news == 0:
                errors.append(Diagnostic(current_category.line, "empty_category", "类别下没有 news，应省略空类别。"))
            current_category = None
            category_news = 0
        if block.kind == "section":
            if current_section and section_content == 0:
                errors.append(Diagnostic(current_section.line, "empty_section", "分区没有内容，应省略空分区。"))
            current_section = block
            section_content = 0
        elif block.kind == "category":
            if current_section is None:
                errors.append(Diagnostic(block.line, "category_context", "category 前必须声明 section。"))
            current_category = block
        elif block.kind == "news":
            if current_section is None or current_category is None:
                errors.append(Diagnostic(block.line, "news_context", "news 前须有当前 section 和 category；经过分隔/提示等模块后须重新声明类别。"))
            category_news += 1
        if current_section and block.kind in CONTENT_MODULES:
            section_content += 1
        links = _validate_body(block, spec, template, errors, allow_demo)
        if block.kind == "news":
            sources = [link for link in links if not link.image and _target_valid(link.url, False, template)]
            if not sources:
                errors.append(Diagnostic(block.line, "news_source", "每个 news 至少包含一个显式 HTTP(S) 原文链接，图片/裸 URL/代码不算。"))
            elif normal_source_urls is not None and not any(link.url in normal_source_urls for link in sources):
                errors.append(Diagnostic(block.line, "source_membership", "news 没有包含本次提供的原文 URL 清单中的任何链接。"))
    if current_category and category_news == 0:
        errors.append(Diagnostic(current_category.line, "empty_category", "类别下没有 news，应省略空类别。"))
    if current_section and section_content == 0:
        errors.append(Diagnostic(current_section.line, "empty_section", "分区没有内容，应省略空分区。"))
    for i, block in enumerate(blocks):
        if block.kind == "transition" and re.search(r"查收.*(?:重要提示|其他提醒)", "\n".join(s for _, s in block.body)):
            if not any(b.kind == "notice" for b in blocks[i + 1:]):
                errors.append(Diagnostic(block.line, "dangling_notice_transition", "没有后续 notice 时应省略查收提示的过渡。"))
    if not any(b.kind in {"news", "notice"} for b in blocks):
        warnings.append(Diagnostic(1, "no_dynamic_items", "文件没有 news/notice；若本批均不合格，请在文件之外说明覆盖及筛选结果。"))
    return _result(blocks, errors, warnings, utf16_size)


def _result(blocks: list[Block], errors: list[Diagnostic], warnings: list[Diagnostic], size: int) -> dict:
    errors = sorted(set(errors), key=lambda d: (d.line, d.code))
    return {"ok": not errors, "modules": len(blocks), "news": sum(b.kind == "news" for b in blocks),
            "notices": sum(b.kind == "notice" for b in blocks), "utf16_characters": size,
            "errors": [asdict(d) for d in errors], "warnings": [asdict(d) for d in warnings]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("file", type=Path, help="UTF-8 Hello Week 成稿")
    parser.add_argument("--template", type=Path, default=DEFAULT_TEMPLATE)
    parser.add_argument("--source-urls", type=Path, help="可选：内部原文 URL 字符串数组 JSON")
    parser.add_argument("--allow-demo", action="store_true", help="仅用于合成示例；生产稿禁用")
    parser.add_argument("--json", action="store_true", help="输出机器可读预检结果")
    args = parser.parse_args()
    try:
        template = json.loads(args.template.read_text(encoding="utf-8-sig"))
        urls = None
        if args.source_urls:
            raw = json.loads(args.source_urls.read_text(encoding="utf-8-sig"))
            if not isinstance(raw, list) or not all(isinstance(x, str) for x in raw):
                raise ValueError("原文 URL 清单必须是 JSON 字符串数组。")
            urls = set(raw)
        result = validate_text(args.file.read_bytes().decode("utf-8"), template,
                               allow_demo=args.allow_demo, source_urls=urls)
    except (OSError, UnicodeError, ValueError, KeyError, TypeError) as exc:
        print(f"无法预检：{exc}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"{'通过' if result['ok'] else '未通过'}：{result['modules']} 个模块，{result['news']} 条资讯，{result['notices']} 条提醒。")
        for item in result["errors"] + result["warnings"]:
            print(f"第 {item['line']} 行 [{item['code']}] {item['message']}")
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
