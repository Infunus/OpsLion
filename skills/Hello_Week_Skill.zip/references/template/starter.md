<!-- opslion:hello-week/v1 -->
# Hello Week丨本期标题
<!-- layout: classic -->

:::banner
:::

:::code-intro
:::

:::divider
:::

:::callout 关于投稿
欢迎在栏目中分享日常感受、书影音推荐和摄影作品，让灵感与生活在这里相遇。

署名方式由投稿人决定。以下二维码与装饰来自参考模板，正式使用前请确认投稿入口仍适用。

![投稿二维码](asset:submission-qr)

> 这里填写本期投稿征集说明或入选奖励。
:::

:::divider
:::

:::section 上周回顾
:::

:::category 学术信息
:::

:::news 请替换为真实资讯标题 1
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[请替换为真实资讯标题原文](https://example.com/articles/1)
:::

:::divider
:::

:::transition
看完了上周信息
再来看看下周及后续的重要信息吧
:::

:::section 下周及后续
:::

:::category 学术信息
:::

:::news 示例讲座 21
- 时间：以原文为准的示例时间
- 地点：示例会场
- 详情请见：[示例讲座原文](https://example.com/articles/21)
:::

:::divider
:::

:::contact 联系我们
如有建议或需要协助，请通过公开联系渠道联系栏目团队。

公共邮箱：weekly@example.com

联系人：示例联系人（请由生成文案的 skill 填写当期信息）
:::

:::code-outro
:::

:::spacer 24
:::

:::credits 北京大学信息科学技术学院学生会
文案丨示例作者
排版丨示例排版人员
校对丨示例署名
:::

:::footer
:::